#!/usr/bin/env python3
"""
Test script for the AI Orchestrator
Demonstrates the super-AI system capabilities
"""

import requests
import json
import time


def test_orchestrator(query, query_type='general', self_correction=True):
    """Test the orchestrator with a query."""
    print("\n" + "="*80)
    print(f"🧪 TESTING AI ORCHESTRATOR")
    print("="*80)
    print(f"\n📝 Query: {query}")
    print(f"🎯 Type: {query_type}")
    print(f"🔧 Self-correction: {self_correction}")
    print("\n⏳ Processing... (this may take 30-60 seconds)\n")
    
    start_time = time.time()
    
    try:
        response = requests.post(
            'http://localhost:5000/api/orchestrate',
            headers={'Content-Type': 'application/json'},
            json={
                'query': query,
                'query_type': query_type,
                'self_correction': self_correction
            },
            timeout=120
        )
        
        elapsed = time.time() - start_time
        
        if response.status_code == 200:
            data = response.json()
            
            print("="*80)
            print("✅ SUCCESS")
            print("="*80)
            print(f"\n⏱️  Response Time: {elapsed:.2f}s")
            print(f"🤖 Models Used: {data.get('models_used', 'N/A')}")
            print(f"📊 Quality Score: {data.get('quality_score', 'N/A')}")
            print("\n" + "="*80)
            print("📤 UNIFIED RESPONSE")
            print("="*80 + "\n")
            print(data.get('response', 'No response'))
            print("\n" + "="*80)
            
            return True
        else:
            print(f"❌ Error: HTTP {response.status_code}")
            print(f"Details: {response.text}")
            return False
            
    except requests.exceptions.Timeout:
        print("❌ Error: Request timed out")
        print("The orchestrator is taking longer than expected.")
        print("This is normal for complex queries with self-correction enabled.")
        return False
    except requests.exceptions.ConnectionError:
        print("❌ Error: Cannot connect to server")
        print("Make sure the server is running: python server.py")
        return False
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return False


def test_individual_ai(ai_name, message):
    """Test an individual AI endpoint."""
    print(f"\n🧪 Testing {ai_name.upper()}...")
    
    endpoints = {
        'groq': '/api/groq/chat',
        'mistral': '/api/mistral/chat',
        'gemini': '/api/gemini/chat',
        'huggingface': '/api/huggingface/chat',
        'cohere': '/api/cohere/chat'
    }
    
    try:
        if ai_name in ['groq', 'mistral']:
            payload = {
                'messages': [
                    {'role': 'user', 'content': message}
                ]
            }
        else:
            payload = {'message': message}
        
        response = requests.post(
            f'http://localhost:5000{endpoints[ai_name]}',
            headers={'Content-Type': 'application/json'},
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            print(f"  ✅ {ai_name.upper()} responded successfully")
            return True
        else:
            print(f"  ❌ {ai_name.upper()} failed: HTTP {response.status_code}")
            return False
            
    except Exception as e:
        print(f"  ❌ {ai_name.upper()} error: {str(e)}")
        return False


def check_server_health():
    """Check if the server is running and healthy."""
    print("\n🏥 Checking server health...")
    
    try:
        response = requests.get('http://localhost:5000/health', timeout=5)
        if response.status_code == 200:
            data = response.json()
            print(f"  ✅ Server is online")
            print(f"  🤖 Available models: {', '.join(data.get('models', []))}")
            print(f"  💾 Memory size: {data.get('memory_size', 0)} conversations")
            return True
        else:
            print(f"  ❌ Server returned HTTP {response.status_code}")
            return False
    except Exception as e:
        print(f"  ❌ Cannot reach server: {str(e)}")
        print("\n💡 Make sure to start the server first:")
        print("   python server.py")
        return False


def main():
    """Run all tests."""
    print("\n" + "="*80)
    print("🚀 AI ORCHESTRATOR TEST SUITE")
    print("="*80)
    
    # Check server health
    if not check_server_health():
        return
    
    print("\n" + "="*80)
    print("📋 TEST PLAN")
    print("="*80)
    print("\n1. Test individual AI endpoints")
    print("2. Test orchestrator with simple query")
    print("3. Test orchestrator with code query")
    print("4. Test orchestrator with analysis query")
    
    input("\n⏸️  Press Enter to start tests...")
    
    # Test 1: Individual AIs
    print("\n" + "="*80)
    print("TEST 1: Individual AI Endpoints")
    print("="*80)
    
    test_message = "Hello, how are you?"
    results = {}
    
    for ai in ['groq', 'gemini', 'mistral', 'huggingface', 'cohere']:
        results[ai] = test_individual_ai(ai, test_message)
    
    working = sum(results.values())
    print(f"\n📊 Result: {working}/5 AI models working")
    
    if working < 3:
        print("\n⚠️  Warning: Less than 3 AI models are working.")
        print("The orchestrator may not function optimally.")
        response = input("Continue anyway? (y/n): ")
        if response.lower() != 'y':
            return
    
    # Test 2: Simple query
    print("\n" + "="*80)
    print("TEST 2: Simple Query")
    print("="*80)
    
    test_orchestrator(
        "What is the capital of France and why is it important?",
        query_type='general',
        self_correction=False  # Faster for testing
    )
    
    input("\n⏸️  Press Enter to continue to next test...")
    
    # Test 3: Code query
    print("\n" + "="*80)
    print("TEST 3: Code Query")
    print("="*80)
    
    test_orchestrator(
        "Write a Python function to check if a string is a palindrome. Include error handling.",
        query_type='code',
        self_correction=False
    )
    
    input("\n⏸️  Press Enter to continue to final test...")
    
    # Test 4: Analysis query with self-correction
    print("\n" + "="*80)
    print("TEST 4: Analysis Query (with self-correction)")
    print("="*80)
    print("\n⚠️  This test will take longer due to self-correction enabled")
    
    test_orchestrator(
        "What are the main differences between machine learning and deep learning?",
        query_type='analysis',
        self_correction=True
    )
    
    # Summary
    print("\n" + "="*80)
    print("✅ TEST SUITE COMPLETE")
    print("="*80)
    print("\n📊 Summary:")
    print(f"  • Individual AIs tested: 5")
    print(f"  • Working AIs: {working}/5")
    print(f"  • Orchestrator tests: 3")
    print("\n🌐 Access the web UI at:")
    print("   http://localhost:5000/orchestrator")
    print("\n" + "="*80)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⏹️  Tests interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {str(e)}")
