from flask import Blueprint, request, jsonify, session
from models.task import Task
from flask_limiter import Limiter
import jwt
from datetime import datetime

tasks_bp = Blueprint('tasks', __name__)

# JWT configuration (same as auth.py)
JWT_SECRET_KEY = 'dev-secret-key-change-in-production'  # Should match auth.py

@tasks_bp.route('/', methods=['GET'])
def get_tasks():
    """Get tasks for the current user with optional filters"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        status = request.args.get('status')
        priority = request.args.get('priority')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))

        tasks = Task.get_tasks_by_user(user_id, status=status, priority=priority, limit=limit, offset=offset)
        return jsonify({
            'tasks': [task.to_dict() for task in tasks],
            'count': len(tasks)
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/', methods=['POST'])
def create_task():
    """Create a new task"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        data = request.json
        user_id = session['user_id']

        title = data.get('title', '').strip()
        if not title:
            return jsonify({'error': 'Title is required'}), 400

        description = data.get('description', '').strip()
        priority = data.get('priority', 'medium')
        due_date_str = data.get('due_date')

        # Validate priority
        if priority not in ['low', 'medium', 'high', 'urgent']:
            return jsonify({'error': 'Invalid priority'}), 400

        # Parse due date if provided
        due_date = None
        if due_date_str:
            try:
                due_date = datetime.fromisoformat(due_date_str.replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'error': 'Invalid due date format'}), 400

        task = Task.create_task(
            user_id=user_id,
            title=title,
            description=description,
            priority=priority,
            due_date=due_date
        )

        return jsonify({
            'message': 'Task created successfully',
            'task': task.to_dict()
        }), 201

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/<int:task_id>', methods=['GET'])
def get_task(task_id):
    """Get a specific task by ID"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        task = Task.get_task_by_id(task_id, user_id=user_id)

        if not task:
            return jsonify({'error': 'Task not found'}), 404

        return jsonify(task.to_dict()), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    """Update a task"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        data = request.json

        # Check if task exists and belongs to user
        task = Task.get_task_by_id(task_id, user_id=user_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        # Validate priority if provided
        if 'priority' in data and data['priority'] not in ['low', 'medium', 'high', 'urgent']:
            return jsonify({'error': 'Invalid priority'}), 400

        # Parse due date if provided
        if 'due_date' in data and data['due_date']:
            try:
                data['due_date'] = datetime.fromisoformat(data['due_date'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'error': 'Invalid due date format'}), 400

        # Update task
        if task.update_task(**data):
            # Get updated task
            updated_task = Task.get_task_by_id(task_id, user_id=user_id)
            return jsonify({
                'message': 'Task updated successfully',
                'task': updated_task.to_dict()
            }), 200
        else:
            return jsonify({'error': 'Failed to update task'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """Delete a task"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']

        # Check if task exists and belongs to user
        task = Task.get_task_by_id(task_id, user_id=user_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        if Task.delete_task_by_id(task_id, user_id=user_id):
            return jsonify({'message': 'Task deleted successfully'}), 200
        else:
            return jsonify({'error': 'Failed to delete task'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/stats', methods=['GET'])
def get_task_stats():
    """Get task statistics for the current user"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        stats = Task.get_task_stats(user_id=user_id)
        return jsonify(stats), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/search', methods=['GET'])
def search_tasks():
    """Search tasks by title or description"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        query = request.args.get('q', '').strip()

        if not query:
            return jsonify({'error': 'Search query is required'}), 400

        limit = int(request.args.get('limit', 20))
        tasks = Task.search_tasks(user_id, query, limit=limit)

        return jsonify({
            'tasks': [task.to_dict() for task in tasks],
            'count': len(tasks),
            'query': query
        }), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@tasks_bp.route('/<int:task_id>/status', methods=['PATCH'])
def update_task_status(task_id):
    """Update only the status of a task"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    try:
        user_id = session['user_id']
        data = request.json

        status = data.get('status')
        if not status or status not in ['pending', 'in_progress', 'completed', 'cancelled']:
            return jsonify({'error': 'Valid status is required'}), 400

        # Check if task exists and belongs to user
        task = Task.get_task_by_id(task_id, user_id=user_id)
        if not task:
            return jsonify({'error': 'Task not found'}), 404

        if task.update_task(status=status):
            updated_task = Task.get_task_by_id(task_id, user_id=user_id)
            return jsonify({
                'message': 'Task status updated successfully',
                'task': updated_task.to_dict()
            }), 200
        else:
            return jsonify({'error': 'Failed to update task status'}), 500

    except Exception as e:
        return jsonify({'error': str(e)}), 500