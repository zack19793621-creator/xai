from flask import Blueprint, request, jsonify, session
from models.user import User
from flask_limiter import Limiter
import jwt
from datetime import datetime, timedelta
import os

auth_bp = Blueprint('auth', __name__)

# JWT configuration
JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'dev-secret-key-change-in-production')
JWT_ACCESS_TOKEN_EXPIRE = timedelta(hours=1)

@auth_bp.route('/register', methods=['POST'])
def register():
    """User registration with improved error handling"""
    try:
        data = request.json
        username = data.get('username', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '')

        if not all([username, email, password]):
            return jsonify({'error': 'All fields are required'}), 400

        if len(password) < 8:
            return jsonify({'error': 'Password must be at least 8 characters'}), 400

        try:
            user = User.create_user(username, email, password)
            return jsonify({
                'message': 'User created successfully',
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'role': user.role
                }
            }), 201
        except ValueError as e:
            return jsonify({'error': str(e)}), 409

    except Exception as e:
        error_msg = str(e)
        # Handle database lock errors specifically
        if "Database temporarily unavailable" in error_msg:
            return jsonify({'error': 'Service temporarily unavailable. Please try again in a few seconds.'}), 503
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    """User login with improved error handling"""
    try:
        data = request.json
        username_or_email = data.get('username', '').strip()
        password = data.get('password', '')

        if not all([username_or_email, password]):
            return jsonify({'error': 'Username/email and password are required'}), 400

        user = User.authenticate_user(username_or_email, password)
        if user:
            session['user_id'] = user.id
            session['username'] = user.username
            session['role'] = user.role

            # Generate JWT token
            token = jwt.encode({
                'user_id': user.id,
                'username': user.username,
                'role': user.role,
                'exp': datetime.utcnow() + JWT_ACCESS_TOKEN_EXPIRE
            }, JWT_SECRET_KEY, algorithm='HS256')

            return jsonify({
                'message': 'Login successful',
                'token': token,
                'user': {
                    'id': user.id,
                    'username': user.username,
                    'email': user.email,
                    'role': user.role
                }
            }), 200
        else:
            return jsonify({'error': 'Invalid credentials'}), 401

    except Exception as e:
        error_msg = str(e)
        # Handle database lock errors specifically
        if "Database temporarily unavailable" in error_msg:
            return jsonify({'error': 'Service temporarily unavailable. Please try again in a few seconds.'}), 503
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """User logout"""
    user_id = session.get('user_id')
    session.clear()
    return jsonify({'message': 'Logout successful'}), 200

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    """Get current user info"""
    if 'user_id' not in session:
        return jsonify({'error': 'Authentication required'}), 401

    user = User.get_user_by_id(session['user_id'])
    if user:
        return jsonify(user.to_dict()), 200
    else:
        return jsonify({'error': 'User not found'}), 404

@auth_bp.route('/verify-token', methods=['POST'])
def verify_token():
    """Verify JWT token"""
    try:
        data = request.json
        token = data.get('token', '')

        if not token:
            return jsonify({'error': 'Token is required'}), 400

        # Decode token
        payload = jwt.decode(token, JWT_SECRET_KEY, algorithms=['HS256'])

        # Check if user still exists and is active
        user = User.get_user_by_id(payload['user_id'])
        if user and user.is_active:
            return jsonify({
                'valid': True,
                'user': user.to_dict()
            }), 200
        else:
            return jsonify({'error': 'Token invalid or user inactive'}), 401

    except jwt.ExpiredSignatureError:
        return jsonify({'error': 'Token expired'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'error': 'Invalid token'}), 401
    except Exception as e:
        return jsonify({'error': 'Token verification failed'}), 500