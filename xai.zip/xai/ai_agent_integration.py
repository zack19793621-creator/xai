"""
AI Agent Integration - Connect AI models to file system operations
Provides multiple integration methods: function calling, code block parsing, and direct API
"""

import re
import json
import requests
from typing import Dict, List, Optional, Any, Tuple, Callable
from pathlib import Path
import time
from ai_file_system import AIFileSystemAgent


class XerAICodeIntegration:
    """
    Integration layer for connecting AI agents to file system operations
    Supports multiple integration patterns for different AI providers
    """

    def __init__(self, project_root: str, api_base_url: str = "http://localhost:5000", safe_mode: bool = True):
        """
        Initialize the integration

        Args:
            project_root: Root directory for file operations
            api_base_url: Base URL for the AI API endpoints
            safe_mode: Whether to use safe mode for file operations
        """
        self.project_root = project_root
        self.api_base_url = api_base_url.rstrip('/')
        self.file_agent = AIFileSystemAgent(project_root, safe_mode=safe_mode)
        self.conversation_history = []
        self.pending_confirmations = {}  # Track operations waiting for confirmation

    def get_system_prompt(self) -> str:
        """
        Get the system prompt that tells AI about file capabilities

        Returns:
            System prompt string
        """
        tools_info = self.file_agent.get_tools_definition()

        tools_description = []
        for tool in tools_info:
            func = tool['function']
            tools_description.append(f"- {func['name']}: {func['description']}")

        return f"""You are XerAI Code with direct file system access.

IMPORTANT CAPABILITIES:
You can create, edit, read, and delete files automatically! Don't just show code - create actual files.

AVAILABLE TOOLS:
{chr(10).join(tools_description)}

WORKFLOW:
1. When user asks to build something, use create_file tool for each file needed
2. Organize properly (src/, components/, etc.)
3. Create all config files (package.json, requirements.txt, etc.)
4. Use edit_file for modifications
5. Use read_file to check existing code
6. Use list_files to explore project structure

SAFETY:
- All operations are within the project directory
- Backups are created automatically
- Use safe_mode=True for user confirmation on destructive operations

RESPONSE FORMAT:
- Use tools when creating/modifying files
- Confirm what you created: "✅ Created X files for your project!"
- Be specific about file paths and purposes

EXAMPLE:
User: "Build a React todo app"
You: [use create_file for App.jsx, TodoList.jsx, package.json]
Then say: "✅ Created 3 files for your todo app. Ready to run with 'npm install && npm start'!"

Remember: Your superpower is creating real files, not just showing code blocks!"""

    def auto_apply_code_blocks(self, ai_response: str) -> Dict[str, Any]:
        """
        Parse code blocks from AI response and automatically create files
        Fallback method for AIs without function calling

        Args:
            ai_response: Raw AI response text

        Returns:
            Dictionary with results of file operations
        """
        # Extract code blocks with language and filename
        # Pattern: ```language filename\ncontent\n```
        code_block_pattern = r'```(\w+)?\s*([^\n]*)\n(.*?)\n```'
        matches = re.findall(code_block_pattern, ai_response, re.DOTALL)

        results = {
            'total_blocks': len(matches),
            'successful_creations': 0,
            'failed_creations': 0,
            'errors': [],
            'files_created': []
        }

        for match in matches:
            language, filename, content = match

            # Skip if no filename provided
            if not filename.strip():
                results['errors'].append(f"Code block without filename: {language or 'unknown'}")
                results['failed_creations'] += 1
                continue

            # Determine file extension from language if not provided
            if '.' not in filename:
                ext_map = {
                    'python': '.py',
                    'javascript': '.js',
                    'typescript': '.ts',
                    'java': '.java',
                    'kotlin': '.kt',
                    'html': '.html',
                    'css': '.css',
                    'json': '.json',
                    'xml': '.xml',
                    'yaml': '.yaml',
                    'yml': '.yml',
                    'md': '.md',
                    'sql': '.sql'
                }
                ext = ext_map.get(language.lower(), '.txt')
                filename = f"{filename}{ext}"

            # Create the file
            result = self.file_agent.create_file(filename, content.strip())

            if result.success:
                results['successful_creations'] += 1
                results['files_created'].append({
                    'path': filename,
                    'language': language,
                    'size': len(content.strip())
                })
            else:
                results['failed_creations'] += 1
                results['errors'].append(f"Failed to create {filename}: {result.error}")

        return results

    def call_ai_with_tools(self, provider: str, message: str, model: Optional[str] = None,
                          temperature: float = 0.7, **kwargs) -> Dict[str, Any]:
        """
        Call AI with function calling tools enabled

        Args:
            provider: AI provider ('openai', 'anthropic', 'groq', etc.)
            message: User message
            model: Specific model to use
            temperature: Temperature setting
            **kwargs: Additional parameters

        Returns:
            AI response with tool calls executed
        """
        # Get tools definition
        tools = self.file_agent.get_tools_definition()

        # Prepare messages
        messages = [
            {"role": "system", "content": self.get_system_prompt()},
            {"role": "user", "content": message}
        ]

        # Add conversation history
        for hist_msg in self.conversation_history[-10:]:  # Last 10 messages
            messages.insert(-1, hist_msg)

        try:
            if provider.lower() == 'openai':
                return self._call_openai_tools(messages, tools, model, temperature, **kwargs)
            elif provider.lower() == 'anthropic':
                return self._call_anthropic_tools(messages, tools, model, temperature, **kwargs)
            elif provider.lower() == 'groq':
                return self._call_groq_tools(messages, tools, model, temperature, **kwargs)
            else:
                # Generic API call
                return self._call_generic_api(provider, messages, tools, model, temperature, **kwargs)

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'response': f"AI call failed: {str(e)}",
                'tool_results': []
            }

    def _call_openai_tools(self, messages: List[Dict], tools: List[Dict], model: str = None,
                          temperature: float = 0.7, **kwargs) -> Dict[str, Any]:
        """Call OpenAI API with tools"""
        import openai

        # Set API key from kwargs or environment
        api_key = kwargs.get('api_key') or openai.api_key
        if not api_key:
            raise ValueError("OpenAI API key required")

        openai.api_key = api_key

        response = openai.ChatCompletion.create(
            model=model or "gpt-4",
            messages=messages,
            tools=tools,
            tool_choice="auto",
            temperature=temperature,
            **kwargs
        )

        return self._process_tool_calls(response, messages)

    def _call_anthropic_tools(self, messages: List[Dict], tools: List[Dict], model: str = None,
                             temperature: float = 0.7, **kwargs) -> Dict[str, Any]:
        """Call Anthropic Claude with tools"""
        import anthropic

        client = anthropic.Anthropic(api_key=kwargs.get('api_key'))
        if not client.api_key:
            raise ValueError("Anthropic API key required")

        # Convert messages to Anthropic format
        anthropic_messages = []
        for msg in messages:
            if msg['role'] == 'system':
                # Add system message as first user message
                anthropic_messages.append({
                    'role': 'user',
                    'content': f"System: {msg['content']}"
                })
                anthropic_messages.append({
                    'role': 'assistant',
                    'content': 'Understood.'
                })
            else:
                anthropic_messages.append(msg)

        response = client.messages.create(
            model=model or "claude-3-5-sonnet-20241022",
            max_tokens=4096,
            tools=tools,
            messages=anthropic_messages,
            temperature=temperature,
            **kwargs
        )

        return self._process_anthropic_tool_calls(response, anthropic_messages)

    def _call_groq_tools(self, messages: List[Dict], tools: List[Dict], model: str = None,
                        temperature: float = 0.7, **kwargs) -> Dict[str, Any]:
        """Call Groq API with tools"""
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            'Authorization': f'Bearer {kwargs.get("api_key")}',
            'Content-Type': 'application/json'
        }

        data = {
            'model': model or 'gemma2-9b-it',
            'messages': messages,
            'tools': tools,
            'tool_choice': 'auto',
            'temperature': temperature,
            **kwargs
        }

        response = requests.post(url, headers=headers, json=data, timeout=60)
        if response.status_code != 200:
            raise Exception(f"Groq API error: {response.status_code} - {response.text}")

        result = response.json()
        return self._process_tool_calls(result, messages)

    def _call_generic_api(self, provider: str, messages: List[Dict], tools: List[Dict],
                         model: str = None, temperature: float = 0.7, **kwargs) -> Dict[str, Any]:
        """Generic API call for other providers"""
        # This is a fallback - implement specific provider logic as needed
        endpoint = kwargs.get('endpoint', f'/api/{provider}/chat')
        url = f"{self.api_base_url}{endpoint}"

        data = {
            'messages': messages,
            'model': model,
            'temperature': temperature,
            'tools': tools,
            **kwargs
        }

        response = requests.post(url, json=data, timeout=60)
        if response.status_code != 200:
            raise Exception(f"API error: {response.status_code} - {response.text}")

        result = response.json()
        return self._process_tool_calls(result, messages)

    def _process_tool_calls(self, response: Dict, messages: List[Dict]) -> Dict[str, Any]:
        """Process tool calls from OpenAI/Groq style responses"""
        tool_results = []

        if 'choices' in response and response['choices']:
            choice = response['choices'][0]
            message = choice.get('message', {})

            # Check for tool calls
            if 'tool_calls' in message and message['tool_calls']:
                for tool_call in message['tool_calls']:
                    tool_name = tool_call['function']['name']
                    tool_args = json.loads(tool_call['function']['arguments'])

                    # Execute the tool
                    result = self.file_agent.execute_tool(tool_name, tool_args)
                    tool_results.append({
                        'tool': tool_name,
                        'args': tool_args,
                        'result': result
                    })

                    # Add tool result to conversation
                    messages.append(message)
                    messages.append({
                        'role': 'tool',
                        'content': json.dumps(result),
                        'tool_call_id': tool_call['id']
                    })

            response_text = message.get('content', '')
        else:
            response_text = str(response)

        # Update conversation history
        self.conversation_history.append({'role': 'assistant', 'content': response_text})

        return {
            'success': True,
            'response': response_text,
            'tool_results': tool_results,
            'files_created': len([r for r in tool_results if r['result'].get('success')])
        }

    def _process_anthropic_tool_calls(self, response, messages: List[Dict]) -> Dict[str, Any]:
        """Process tool calls from Anthropic responses"""
        tool_results = []

        if response.stop_reason == "tool_use":
            for block in response.content:
                if block.type == "tool_use":
                    tool_name = block.name
                    tool_args = block.input

                    # Execute the tool
                    result = self.file_agent.execute_tool(tool_name, tool_args)
                    tool_results.append({
                        'tool': tool_name,
                        'args': tool_args,
                        'result': result
                    })

                    # Add tool result to conversation
                    messages.append({
                        'role': 'assistant',
                        'content': f"Used tool: {tool_name}"
                    })
                    messages.append({
                        'role': 'user',
                        'content': f"Tool result: {json.dumps(result)}"
                    })

        # Extract text content
        response_text = ""
        for block in response.content:
            if block.type == "text":
                response_text += block.text

        # Update conversation history
        self.conversation_history.append({'role': 'assistant', 'content': response_text})

        return {
            'success': True,
            'response': response_text,
            'tool_results': tool_results,
            'files_created': len([r for r in tool_results if r['result'].get('success')])
        }

    def confirm_pending_operation(self, operation_id: str, confirmed: bool) -> Dict[str, Any]:
        """
        Confirm or reject a pending operation

        Args:
            operation_id: ID of the pending operation
            confirmed: Whether to proceed with the operation

        Returns:
            Result of the operation
        """
        if operation_id not in self.pending_confirmations:
            return {
                'success': False,
                'error': 'Operation not found or already processed'
            }

        operation = self.pending_confirmations.pop(operation_id)

        if not confirmed:
            return {
                'success': True,
                'message': 'Operation cancelled by user',
                'cancelled': True
            }

        # Execute the operation
        result = self.file_agent.execute_tool(operation['tool'], operation['params'])

        return {
            'success': result['success'],
            'message': result['message'],
            'error': result['error'],
            'data': result['data']
        }

    def get_pending_confirmations(self) -> List[Dict[str, Any]]:
        """
        Get list of operations waiting for confirmation

        Returns:
            List of pending operations
        """
        return [
            {
                'id': op_id,
                'tool': op['tool'],
                'params': op['params'],
                'timestamp': op['timestamp']
            }
            for op_id, op in self.pending_confirmations.items()
        ]

    def batch_create_files(self, files: List[Dict[str, str]]) -> Dict[str, Any]:
        """
        Create multiple files in batch

        Args:
            files: List of dicts with 'path' and 'content' keys

        Returns:
            Batch operation results
        """
        results = {
            'total': len(files),
            'successful': 0,
            'failed': 0,
            'errors': [],
            'files_created': []
        }

        for file_info in files:
            path = file_info.get('path', '')
            content = file_info.get('content', '')

            if not path or not content:
                results['failed'] += 1
                results['errors'].append(f"Invalid file info: {file_info}")
                continue

            result = self.file_agent.create_file(path, content)

            if result.success:
                results['successful'] += 1
                results['files_created'].append(path)
            else:
                results['failed'] += 1
                results['errors'].append(f"Failed to create {path}: {result.error}")

        return results

    def create_project_template(self, template_name: str, project_name: str) -> Dict[str, Any]:
        """
        Create a project from a template

        Args:
            template_name: Name of the template ('react', 'flask', 'django', etc.)
            project_name: Name of the new project

        Returns:
            Project creation results
        """
        templates = {
            'react': {
                'package.json': json.dumps({
                    'name': project_name,
                    'version': '1.0.0',
                    'scripts': {
                        'start': 'react-scripts start',
                        'build': 'react-scripts build'
                    },
                    'dependencies': {
                        'react': '^18.2.0',
                        'react-dom': '^18.2.0'
                    },
                    'devDependencies': {
                        'react-scripts': '5.0.1'
                    }
                }, indent=2),
                'src/App.js': '''import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Hello, React!</h1>
      </header>
    </div>
  );
}

export default App;''',
                'src/index.js': '''import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);''',
                'public/index.html': '''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>React App</title>
</head>
<body>
    <div id="root"></div>
</body>
</html>'''
            },
            'flask': {
                'app.py': f'''from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello():
    return "Hello from {project_name}!"

if __name__ == '__main__':
    app.run(debug=True)''',
                'requirements.txt': '''Flask==2.3.3
Werkzeug==2.3.7''',
                'README.md': f'# {project_name}\n\nA Flask web application.'
            }
        }

        if template_name not in templates:
            return {
                'success': False,
                'error': f'Template not found: {template_name}',
                'available_templates': list(templates.keys())
            }

        template = templates[template_name]
        files_to_create = []

        for file_path, content in template.items():
            files_to_create.append({
                'path': file_path,
                'content': content
            })

        return self.batch_create_files(files_to_create)

    def get_project_status(self) -> Dict[str, Any]:
        """
        Get current project status and file system state

        Returns:
            Project status information
        """
        try:
            # Get file listing
            file_list = self.file_agent.list_files(".", recursive=True)

            # Get change history
            changes = self.file_agent.get_change_history()

            return {
                'success': True,
                'project_root': self.project_root,
                'total_files': len(file_list.get('data', {}).get('files', [])),
                'total_changes': len(changes),
                'safe_mode': self.file_agent.safe_mode,
                'pending_confirmations': len(self.pending_confirmations),
                'recent_changes': changes[-5:]  # Last 5 changes
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }