from datetime import datetime
import sqlite3
import os

class Task:
    """Task model for task management system"""

    def __init__(self, id=None, user_id=None, title=None, description=None,
                 status='pending', priority='medium', due_date=None,
                 created_at=None, updated_at=None):
        self.id = id
        self.user_id = user_id
        self.title = title
        self.description = description
        self.status = status  # pending, in_progress, completed, cancelled
        self.priority = priority  # low, medium, high, urgent
        self.due_date = due_date
        self.created_at = created_at or datetime.utcnow()
        self.updated_at = updated_at or datetime.utcnow()

    @staticmethod
    def get_db_connection():
        """Get database connection with proper configuration"""
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ai_orchestrator.db')
        conn = sqlite3.connect(db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        # Enable WAL mode for better concurrent access
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        conn.execute('PRAGMA cache_size=1000')
        conn.execute('PRAGMA temp_store=MEMORY')
        return conn

    @classmethod
    def create_task(cls, user_id, title, description=None, priority='medium', due_date=None):
        """Create a new task"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO tasks (user_id, title, description, priority, due_date, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (user_id, title, description, priority, due_date, datetime.utcnow(), datetime.utcnow()))
            conn.commit()

            # Return the created task object
            task_id = cursor.lastrowid
            return cls(id=task_id, user_id=user_id, title=title, description=description,
                      priority=priority, due_date=due_date)

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_task_by_id(cls, task_id, user_id=None):
        """Get task by ID, optionally filtered by user_id for security"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()

            if user_id:
                cursor.execute('SELECT * FROM tasks WHERE id = ? AND user_id = ?', (task_id, user_id))
            else:
                cursor.execute('SELECT * FROM tasks WHERE id = ?', (task_id,))

            task_data = cursor.fetchone()
            if task_data:
                return cls(**dict(task_data))
            return None

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_tasks_by_user(cls, user_id, status=None, priority=None, limit=50, offset=0):
        """Get tasks for a specific user with optional filters"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()

            query = 'SELECT * FROM tasks WHERE user_id = ?'
            params = [user_id]

            if status:
                query += ' AND status = ?'
                params.append(status)

            if priority:
                query += ' AND priority = ?'
                params.append(priority)

            query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
            params.extend([limit, offset])

            cursor.execute(query, params)
            tasks_data = cursor.fetchall()

            return [cls(**dict(task_data)) for task_data in tasks_data]

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_all_tasks(cls, limit=100, offset=0):
        """Get all tasks (admin function)"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT * FROM tasks ORDER BY created_at DESC LIMIT ? OFFSET ?',
                          (limit, offset))
            tasks_data = cursor.fetchall()
            return [cls(**dict(task_data)) for task_data in tasks_data]

        finally:
            if 'conn' in locals():
                conn.close()

    def update_task(self, **kwargs):
        """Update task attributes"""
        allowed_fields = ['title', 'description', 'status', 'priority', 'due_date']
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}

        if not updates:
            return False

        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()

            updates['updated_at'] = datetime.utcnow()
            set_clause = ', '.join([f'{field} = ?' for field in updates.keys()])
            values = list(updates.values()) + [self.id]

            cursor.execute(f'UPDATE tasks SET {set_clause} WHERE id = ?', values)
            conn.commit()

            # Update instance attributes
            for field, value in updates.items():
                setattr(self, field, value)

            return True

        finally:
            if 'conn' in locals():
                conn.close()

    def delete_task(self):
        """Delete this task"""
        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('DELETE FROM tasks WHERE id = ?', (self.id,))
            conn.commit()
            return cursor.rowcount > 0

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def delete_task_by_id(cls, task_id, user_id=None):
        """Delete task by ID, optionally filtered by user_id for security"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()

            if user_id:
                cursor.execute('DELETE FROM tasks WHERE id = ? AND user_id = ?', (task_id, user_id))
            else:
                cursor.execute('DELETE FROM tasks WHERE id = ?', (task_id,))

            conn.commit()
            return cursor.rowcount > 0

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_task_stats(cls, user_id=None):
        """Get task statistics"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()

            if user_id:
                cursor.execute('''
                    SELECT
                        COUNT(*) as total_tasks,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks,
                        SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) as urgent_tasks
                    FROM tasks
                    WHERE user_id = ?
                ''', (user_id,))
            else:
                cursor.execute('''
                    SELECT
                        COUNT(*) as total_tasks,
                        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                        SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks,
                        SUM(CASE WHEN priority = 'urgent' THEN 1 ELSE 0 END) as urgent_tasks
                    FROM tasks
                ''')

            stats = cursor.fetchone()
            return dict(stats) if stats else {}

        finally:
            if 'conn' in locals():
                conn.close()

    def to_dict(self):
        """Convert task object to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'description': self.description,
            'status': self.status,
            'priority': self.priority,
            'due_date': self.due_date.isoformat() if isinstance(self.due_date, datetime) else self.due_date,
            'created_at': self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at,
            'updated_at': self.updated_at.isoformat() if isinstance(self.updated_at, datetime) else self.updated_at
        }

    @classmethod
    def search_tasks(cls, user_id, query, limit=20):
        """Search tasks by title or description"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()

            search_query = f'%{query}%'
            cursor.execute('''
                SELECT * FROM tasks
                WHERE user_id = ? AND (title LIKE ? OR description LIKE ?)
                ORDER BY created_at DESC
                LIMIT ?
            ''', (user_id, search_query, search_query, limit))

            tasks_data = cursor.fetchall()
            return [cls(**dict(task_data)) for task_data in tasks_data]

        finally:
            if 'conn' in locals():
                conn.close()