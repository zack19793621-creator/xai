from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import sqlite3
import os

class User:
    """User model for authentication and user management"""

    def __init__(self, id=None, username=None, email=None, password_hash=None,
                 role='user', created_at=None, last_login=None, is_active=True):
        self.id = id
        self.username = username
        self.email = email
        self.password_hash = password_hash
        self.role = role
        self.created_at = created_at or datetime.utcnow()
        self.last_login = last_login
        self.is_active = is_active

    @staticmethod
    def get_db_connection():
        """Get database connection with proper configuration"""
        db_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'ai_orchestrator.db')
        conn = sqlite3.connect(db_path, timeout=10.0)
        conn.row_factory = sqlite3.Row
        # Enable WAL mode for better concurrent access
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        conn.execute('PRAGMA cache_size=1000')
        conn.execute('PRAGMA temp_store=MEMORY')
        return conn

    @classmethod
    def create_user(cls, username, email, password, role='user'):
        """Create a new user with database lock handling"""
        password_hash = generate_password_hash(password)
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role, created_at)
                VALUES (?, ?, ?, ?, ?)
            ''', (username, email, password_hash, role, datetime.utcnow()))
            conn.commit()

            # Return the created user object
            user_id = cursor.lastrowid
            return cls(id=user_id, username=username, email=email,
                      password_hash=password_hash, role=role)

        except sqlite3.IntegrityError:
            raise ValueError("Username or email already exists")
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                raise Exception("Database temporarily unavailable. Please try again.")
            raise e
        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def authenticate_user(cls, username_or_email, password):
        """Authenticate a user with database lock handling"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            user_data = cursor.execute(
                'SELECT * FROM users WHERE (username = ? OR email = ?) AND is_active = 1',
                (username_or_email, username_or_email)
            ).fetchone()

            if user_data and check_password_hash(user_data['password_hash'], password):
                # Update last login
                cursor.execute('UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?',
                              (user_data['id'],))
                conn.commit()

                return cls(**dict(user_data))
            return None

        except sqlite3.OperationalError as e:
            if "database is locked" in str(e):
                raise Exception("Database temporarily unavailable. Please try again.")
            raise e
        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_user_by_id(cls, user_id):
        """Get user by ID"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            user_data = cursor.execute(
                'SELECT * FROM users WHERE id = ? AND is_active = 1',
                (user_id,)
            ).fetchone()

            if user_data:
                return cls(**dict(user_data))
            return None

        finally:
            if 'conn' in locals():
                conn.close()

    @classmethod
    def get_all_users(cls):
        """Get all active users (admin function)"""
        try:
            conn = cls.get_db_connection()
            cursor = conn.cursor()
            users_data = cursor.execute(
                'SELECT id, username, email, role, created_at, last_login, is_active FROM users WHERE is_active = 1'
            ).fetchall()

            return [cls(**dict(user_data)) for user_data in users_data]

        finally:
            if 'conn' in locals():
                conn.close()

    def update_profile(self, **kwargs):
        """Update user profile"""
        allowed_fields = ['email', 'role', 'is_active']
        updates = {k: v for k, v in kwargs.items() if k in allowed_fields}

        if not updates:
            return False

        try:
            conn = self.get_db_connection()
            cursor = conn.cursor()

            set_clause = ', '.join([f'{field} = ?' for field in updates.keys()])
            values = list(updates.values()) + [self.id]

            cursor.execute(f'UPDATE users SET {set_clause} WHERE id = ?', values)
            conn.commit()

            # Update instance attributes
            for field, value in updates.items():
                setattr(self, field, value)

            return True

        finally:
            if 'conn' in locals():
                conn.close()

    def to_dict(self):
        """Convert user object to dictionary"""
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'role': self.role,
            'created_at': self.created_at.isoformat() if isinstance(self.created_at, datetime) else self.created_at,
            'last_login': self.last_login.isoformat() if isinstance(self.last_login, datetime) else self.last_login,
            'is_active': self.is_active
        }