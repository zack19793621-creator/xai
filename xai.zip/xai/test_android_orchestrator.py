"""
Test script for Android AI Orchestrator
Verifies all components are working correctly
"""

import asyncio
import json
from android_orchestrator import AndroidOrchestrator, TaskStatus, TodoItem, CodeDiff


async def test_query_analysis():
    """Test query analysis functionality"""
    print("\n" + "="*80)
    print("TEST 1: Query Analysis")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    test_queries = [
        "Build the app with Gradle",
        "Implement real-time audio recording",
        "Add Gemini AI for translation",
        "Create a new file called MainActivity.kt"
    ]
    
    for query in test_queries:
        analysis = orchestrator.analyze_query(query)
        print(f"\nQuery: {query}")
        print(f"Analysis: {json.dumps(analysis, indent=2)}")
    
    print("\n✅ Query analysis test completed")


async def test_code_generation():
    """Test code generation with AI consensus"""
    print("\n" + "="*80)
    print("TEST 2: Code Generation")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    task = "Create a simple Kotlin function to calculate factorial"
    print(f"\nTask: {task}")
    
    try:
        result = await orchestrator.generate_code(task)
        
        if result['success']:
            print(f"\n✅ Code generated successfully!")
            print(f"Model: {result['model']}")
            print(f"Confidence: {result['confidence']}")
            print(f"\nGenerated {len(result['code'])} code block(s)")
            
            for i, code_block in enumerate(result['code'], 1):
                print(f"\nCode Block {i} ({code_block['language']}):")
                print("-" * 40)
                print(code_block['code'][:200] + "..." if len(code_block['code']) > 200 else code_block['code'])
        else:
            print(f"\n❌ Code generation failed: {result.get('error')}")
    
    except Exception as e:
        print(f"\n❌ Error during code generation: {str(e)}")
    
    print("\n✅ Code generation test completed")


async def test_file_operations():
    """Test file creation and modification"""
    print("\n" + "="*80)
    print("TEST 3: File Operations")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    # Test file creation
    test_file = "test_output/TestFile.kt"
    test_content = """
package com.example.test

class TestFile {
    fun greet(name: String): String {
        return "Hello, $name!"
    }
}
"""
    
    print(f"\nCreating file: {test_file}")
    success = await orchestrator.create_file(test_file, test_content)
    
    if success:
        print(f"✅ File created successfully")
        print(f"File added to workspace: {test_file in orchestrator.workspace['files']}")
    else:
        print(f"❌ File creation failed")
    
    print("\n✅ File operations test completed")


async def test_ui_state():
    """Test UI state management"""
    print("\n" + "="*80)
    print("TEST 4: UI State Management")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    # Simulate some activity
    orchestrator._log_terminal("Test log entry 1")
    orchestrator._log_terminal("Test log entry 2")
    orchestrator._update_sidebar("Test task", 0.95)
    
    # Get UI state
    ui_state = orchestrator.get_ui_state()
    
    print("\nUI State:")
    print(json.dumps(ui_state, indent=2))
    
    print("\n✅ UI state test completed")


async def test_knowledge_store():
    """Test MCP-compatible knowledge storage"""
    print("\n" + "="*80)
    print("TEST 5: Knowledge Store")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    # Store knowledge
    orchestrator.knowledge_store.store(
        "test_pattern",
        "AudioRecord implementation pattern",
        {"type": "code_pattern", "language": "kotlin"}
    )
    
    # Retrieve knowledge
    retrieved = orchestrator.knowledge_store.retrieve("test_pattern")
    print(f"\nStored: AudioRecord implementation pattern")
    print(f"Retrieved: {retrieved}")
    
    # Search knowledge
    results = orchestrator.knowledge_store.search("audio")
    print(f"\nSearch results for 'audio': {len(results)} found")
    
    print("\n✅ Knowledge store test completed")


async def test_autonomous_mode():
    """Test autonomous mode (without actual build)"""
    print("\n" + "="*80)
    print("TEST 6: Autonomous Mode (Simulation)")
    print("="*80)
    
    orchestrator = AndroidOrchestrator()
    
    # Test request that doesn't require actual build
    request = "Explain how to implement real-time audio recording in Android"
    
    print(f"\nRequest: {request}")
    print("\nProcessing in autonomous mode...")
    
    try:
        result = await orchestrator.process_request(request, autonomous=False)
        
        if result['success']:
            print(f"\n✅ Request processed successfully!")
            print(f"Models used: {result.get('models_used', [])}")
            print(f"\nResponse preview:")
            response_text = result.get('response', '')
            print(response_text[:300] + "..." if len(response_text) > 300 else response_text)
        else:
            print(f"\n❌ Request processing failed: {result.get('error')}")
    
    except Exception as e:
        print(f"\n❌ Error during autonomous mode: {str(e)}")
    
    print("\n✅ Autonomous mode test completed")


async def run_all_tests():
    """Run all tests"""
    print("\n" + "="*80)
    print("🧪 ANDROID AI ORCHESTRATOR - TEST SUITE")
    print("="*80)
    
    tests = [
        test_query_analysis,
        test_code_generation,
        test_file_operations,
        test_ui_state,
        test_knowledge_store,
        test_autonomous_mode
    ]
    
    for test in tests:
        try:
            await test()
        except Exception as e:
            print(f"\n❌ Test failed with error: {str(e)}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*80)
    print("✅ ALL TESTS COMPLETED")
    print("="*80)
    print("\nNote: Some tests may show errors if the Flask server is not running.")
    print("Start the server with: python server.py")
    print("Then access the UI at: http://localhost:5000/android")


if __name__ == "__main__":
    asyncio.run(run_all_tests())
