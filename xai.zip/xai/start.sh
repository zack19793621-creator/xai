#!/bin/bash

# Android AI Orchestrator - Quick Start Script

echo "=================================="
echo "🚀 Android AI Orchestrator"
echo "=================================="
echo ""

# Check Python version
echo "Checking Python version..."
python_version=$(python3 --version 2>&1 | awk '{print $2}')
echo "✅ Python $python_version detected"
echo ""

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    echo "✅ Virtual environment created"
else
    echo "✅ Virtual environment already exists"
fi
echo ""

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
echo "✅ Virtual environment activated"
echo ""

# Install dependencies
echo "Installing dependencies..."
pip install -q -r requirements.txt
echo "✅ Dependencies installed"
echo ""

# Check for Android SDK (optional)
if [ -z "$ANDROID_HOME" ]; then
    echo "⚠️  ANDROID_HOME not set (optional for builds)"
    echo "   To enable Gradle builds, set:"
    echo "   export ANDROID_HOME=/path/to/android-sdk"
else
    echo "✅ ANDROID_HOME: $ANDROID_HOME"
fi
echo ""

# Start server
echo "=================================="
echo "🚀 Starting Server..."
echo "=================================="
echo ""
echo "Server will be available at:"
echo "  🌐 Main UI:        http://localhost:5000"
echo "  🤖 Android UI:     http://localhost:5000/android"
echo "  📊 Orchestrator:   http://localhost:5000/orchestrator"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "=================================="
echo ""

python3 server.py
