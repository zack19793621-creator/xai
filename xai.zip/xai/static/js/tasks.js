// Task Management JavaScript
let currentUser = null;
let currentFilters = {
    status: '',
    priority: '',
    search: ''
};

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    loadTasks();
    loadStats();
    setupEventListeners();
});

// Authentication check
async function checkAuth() {
    try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
            currentUser = await response.json();
            document.getElementById('user-info').textContent = `Welcome, ${currentUser.username}!`;
        } else {
            window.location.href = '/';
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        window.location.href = '/';
    }
}

// Logout function
function logout() {
    fetch('/api/auth/logout', { method: 'POST' })
        .then(() => {
            window.location.href = '/';
        })
        .catch(error => console.error('Logout failed:', error));
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    document.getElementById('search-input').addEventListener('input', debounce(handleSearch, 300));

    // Filters
    document.getElementById('status-filter').addEventListener('change', handleFilterChange);
    document.getElementById('priority-filter').addEventListener('change', handleFilterChange);
}

// Debounce utility
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Handle search
function handleSearch(event) {
    currentFilters.search = event.target.value;
    loadTasks();
}

// Handle filter changes
function handleFilterChange() {
    currentFilters.status = document.getElementById('status-filter').value;
    currentFilters.priority = document.getElementById('priority-filter').value;
    loadTasks();
}

// Load tasks from API
async function loadTasks() {
    try {
        const params = new URLSearchParams();
        if (currentFilters.status) params.append('status', currentFilters.status);
        if (currentFilters.priority) params.append('priority', currentFilters.priority);

        let url = '/api/tasks/';
        if (currentFilters.search) {
            url = '/api/tasks/search';
            params.append('q', currentFilters.search);
        }

        const response = await fetch(`${url}?${params}`);
        if (response.ok) {
            const data = await response.json();
            renderTasks(data.tasks || []);
        } else {
            showError('Failed to load tasks');
        }
    } catch (error) {
        console.error('Load tasks failed:', error);
        showError('Failed to load tasks');
    }
}

// Load statistics
async function loadStats() {
    try {
        const response = await fetch('/api/tasks/stats');
        if (response.ok) {
            const stats = await response.json();
            updateStats(stats);
        }
    } catch (error) {
        console.error('Load stats failed:', error);
    }
}

// Update statistics display
function updateStats(stats) {
    document.getElementById('total-tasks').textContent = stats.total_tasks || 0;
    document.getElementById('completed-tasks').textContent = stats.completed_tasks || 0;
    document.getElementById('in-progress-tasks').textContent = stats.in_progress_tasks || 0;
    document.getElementById('urgent-tasks').textContent = stats.urgent_tasks || 0;
}

// Render tasks
function renderTasks(tasks) {
    const container = document.getElementById('tasks-container');

    if (tasks.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No tasks found</h5>
                <p class="text-muted">Create your first task to get started!</p>
                <button class="btn btn-primary" onclick="showCreateModal()">
                    <i class="fas fa-plus me-1"></i>Create Task
                </button>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div class="row">
            ${tasks.map(task => createTaskCard(task)).join('')}
        </div>
    `;
}

// Create task card HTML
function createTaskCard(task) {
    const priorityClass = `priority-${task.priority}`;
    const statusIcon = getStatusIcon(task.status);
    const statusBadge = getStatusBadge(task.status);
    const dueDate = task.due_date ? new Date(task.due_date).toLocaleDateString() : 'No due date';

    return `
        <div class="col-md-6 col-lg-4 mb-4">
            <div class="card task-card ${task.status} h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h6 class="card-title mb-0">${escapeHtml(task.title)}</h6>
                        <div class="task-actions">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#" onclick="editTask(${task.id})">
                                        <i class="fas fa-edit me-2"></i>Edit
                                    </a></li>
                                    <li><a class="dropdown-item" href="#" onclick="showStatusModal(${task.id}, '${task.status}')">
                                        <i class="fas fa-tasks me-2"></i>Update Status
                                    </a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="#" onclick="deleteTask(${task.id})">
                                        <i class="fas fa-trash me-2"></i>Delete
                                    </a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <p class="card-text text-muted small mb-2">${escapeHtml(task.description || 'No description')}</p>

                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="badge ${priorityClass}">${task.priority.toUpperCase()}</span>
                        ${statusBadge}
                    </div>

                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">
                            <i class="fas fa-calendar me-1"></i>${dueDate}
                        </small>
                        <small class="text-muted">
                            <i class="fas fa-clock me-1"></i>${new Date(task.created_at).toLocaleDateString()}
                        </small>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Get status icon
function getStatusIcon(status) {
    const icons = {
        'pending': 'fas fa-clock',
        'in_progress': 'fas fa-spinner fa-spin',
        'completed': 'fas fa-check-circle',
        'cancelled': 'fas fa-times-circle'
    };
    return icons[status] || 'fas fa-question-circle';
}

// Get status badge
function getStatusBadge(status) {
    const badges = {
        'pending': '<span class="badge bg-warning status-badge">Pending</span>',
        'in_progress': '<span class="badge bg-primary status-badge">In Progress</span>',
        'completed': '<span class="badge bg-success status-badge">Completed</span>',
        'cancelled': '<span class="badge bg-danger status-badge">Cancelled</span>'
    };
    return badges[status] || '<span class="badge bg-secondary status-badge">Unknown</span>';
}

// Show create task modal
function showCreateModal() {
    document.getElementById('modal-title').textContent = 'Create New Task';
    document.getElementById('task-id').value = '';
    document.getElementById('task-title').value = '';
    document.getElementById('task-description').value = '';
    document.getElementById('task-priority').value = 'medium';
    document.getElementById('task-due-date').value = '';

    const modal = new bootstrap.Modal(document.getElementById('taskModal'));
    modal.show();
}

// Edit task
async function editTask(taskId) {
    try {
        const response = await fetch(`/api/tasks/${taskId}`);
        if (response.ok) {
            const task = await response.json();

            document.getElementById('modal-title').textContent = 'Edit Task';
            document.getElementById('task-id').value = task.id;
            document.getElementById('task-title').value = task.title;
            document.getElementById('task-description').value = task.description || '';
            document.getElementById('task-priority').value = task.priority;

            // Format due date for datetime-local input
            if (task.due_date) {
                const dueDate = new Date(task.due_date);
                const formatted = dueDate.toISOString().slice(0, 16);
                document.getElementById('task-due-date').value = formatted;
            } else {
                document.getElementById('task-due-date').value = '';
            }

            const modal = new bootstrap.Modal(document.getElementById('taskModal'));
            modal.show();
        } else {
            showError('Failed to load task');
        }
    } catch (error) {
        console.error('Edit task failed:', error);
        showError('Failed to load task');
    }
}

// Save task
async function saveTask() {
    const taskId = document.getElementById('task-id').value;
    const title = document.getElementById('task-title').value.trim();
    const description = document.getElementById('task-description').value.trim();
    const priority = document.getElementById('task-priority').value;
    const dueDate = document.getElementById('task-due-date').value;

    if (!title) {
        showError('Title is required');
        return;
    }

    const taskData = {
        title,
        description,
        priority,
        due_date: dueDate || null
    };

    try {
        let response;
        if (taskId) {
            // Update existing task
            response = await fetch(`/api/tasks/${taskId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        } else {
            // Create new task
            response = await fetch('/api/tasks/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(taskData)
            });
        }

        if (response.ok) {
            const result = await response.json();
            showSuccess(taskId ? 'Task updated successfully' : 'Task created successfully');

            // Close modal and reload tasks
            bootstrap.Modal.getInstance(document.getElementById('taskModal')).hide();
            loadTasks();
            loadStats();
        } else {
            const error = await response.json();
            showError(error.error || 'Failed to save task');
        }
    } catch (error) {
        console.error('Save task failed:', error);
        showError('Failed to save task');
    }
}

// Show status update modal
function showStatusModal(taskId, currentStatus) {
    document.getElementById('status-task-id').value = taskId;
    document.getElementById('task-status').value = currentStatus;

    const modal = new bootstrap.Modal(document.getElementById('statusModal'));
    modal.show();
}

// Update task status
async function updateStatus() {
    const taskId = document.getElementById('status-task-id').value;
    const status = document.getElementById('task-status').value;

    try {
        const response = await fetch(`/api/tasks/${taskId}/status`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });

        if (response.ok) {
            showSuccess('Task status updated successfully');

            // Close modal and reload tasks
            bootstrap.Modal.getInstance(document.getElementById('statusModal')).hide();
            loadTasks();
            loadStats();
        } else {
            const error = await response.json();
            showError(error.error || 'Failed to update status');
        }
    } catch (error) {
        console.error('Update status failed:', error);
        showError('Failed to update status');
    }
}

// Delete task
async function deleteTask(taskId) {
    if (!confirm('Are you sure you want to delete this task?')) {
        return;
    }

    try {
        const response = await fetch(`/api/tasks/${taskId}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showSuccess('Task deleted successfully');
            loadTasks();
            loadStats();
        } else {
            const error = await response.json();
            showError(error.error || 'Failed to delete task');
        }
    } catch (error) {
        console.error('Delete task failed:', error);
        showError('Failed to delete task');
    }
}

// Utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showSuccess(message) {
    // Simple success notification - you could enhance this with a proper toast library
    alert(message);
}

function showError(message) {
    // Simple error notification - you could enhance this with a proper toast library
    alert('Error: ' + message);
}