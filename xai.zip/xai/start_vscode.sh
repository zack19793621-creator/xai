#!/bin/bash

# VS Code AI Builder - Quick Start Script

echo "=================================="
echo "🚀 VS Code AI Builder Launcher"
echo "=================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python 3 found"

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip."
    exit 1
fi

echo "✅ pip3 found"

# Install dependencies if needed
if [ ! -d "venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv venv
fi

echo "🔧 Activating virtual environment..."
source venv/bin/activate

echo "📦 Installing/updating dependencies..."
pip install -q -r requirements.txt

echo ""
echo "=================================="
echo "🎯 Starting VS Code AI Builder"
echo "=================================="
echo ""
echo "Server will start on: http://localhost:5000"
echo ""
echo "Available interfaces:"
echo "  • VS Code AI Builder:  http://localhost:5000/vscode  ⭐ RECOMMENDED"
echo "  • Android Dev UI:      http://localhost:5000/android"
echo "  • AI Orchestrator:     http://localhost:5000/orchestrator"
echo "  • Classic UI:          http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""
echo "=================================="
echo ""

# Start the server
python3 server.py
