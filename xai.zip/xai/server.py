from flask import Flask, request, jsonify, send_file, session, redirect, url_for, flash, render_template
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_session import Session
from flask_socketio import SocketIO, emit, join_room, leave_room
import requests
import json
import os
import subprocess
from pathlib import Path
import sqlite3
from datetime import datetime, timedelta
import hashlib
import secrets
import logging
from logging.handlers import RotatingFileHandler
import time
from functools import wraps
import jwt
from werkzeug.security import generate_password_hash, check_password_hash
import prometheus_client
from prometheus_client import Counter, Histogram, Gauge

# Import blueprints
from routes.auth import auth_bp
from routes.tasks import tasks_bp

# Import AI file system components
from ai_file_system import AIFileSystemAgent
from ai_agent_integration import XerAICodeIntegration

class Config:
    """Application configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = False
    SESSION_USE_SIGNER = True
    SESSION_KEY_PREFIX = 'ai_orchestrator:'

    # Database
    DATABASE_PATH = os.path.join(os.path.dirname(__file__), 'ai_orchestrator.db')

    # JWT
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', secrets.token_hex(32))
    JWT_ACCESS_TOKEN_EXPIRE = timedelta(hours=1)

    # Rate limiting
    RATELIMIT_STORAGE_URL = "memory://"
    RATELIMIT_STRATEGY = "fixed-window"

    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FILE = os.path.join(os.path.dirname(__file__), 'logs', 'ai_orchestrator.log')

    # Monitoring
    PROMETHEUS_PORT = int(os.environ.get('PROMETHEUS_PORT', 8000))

app = Flask(__name__)
app.config.from_object(Config)

# Initialize extensions
CORS(app, origins=["http://localhost:5000", "http://127.0.0.1:5000"])
Session(app)
limiter = Limiter(app=app, key_func=get_remote_address, storage_uri=app.config['RATELIMIT_STORAGE_URL'])

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(tasks_bp, url_prefix='/api/tasks')

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins=["http://localhost:5000", "http://127.0.0.1:5000"], async_mode='threading')

# Initialize XerAI Code Integration
xerai_integration = XerAICodeIntegration(
    project_root=os.path.dirname(__file__),
    api_base_url="http://localhost:5000",
    safe_mode=True
)

# Setup logging
os.makedirs(os.path.dirname(app.config['LOG_FILE']), exist_ok=True)
handler = RotatingFileHandler(app.config['LOG_FILE'], maxBytes=10*1024*1024, backupCount=5)
handler.setFormatter(logging.Formatter(
    '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
))
app.logger.addHandler(handler)
app.logger.setLevel(getattr(logging, app.config['LOG_LEVEL']))

# Prometheus metrics
REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP request latency', ['method', 'endpoint'])
ACTIVE_USERS = Gauge('active_users', 'Number of active users')
MEMORY_USAGE = Gauge('memory_usage_bytes', 'Memory usage in bytes')

# Your API Keys - All models integrated
API_KEYS = {
    'groq': os.environ.get('GROQ_API_KEY', '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'),
    'mistral': os.environ.get('MISTRAL_API_KEY', 'iUmDy5KkQKhdhQU0j013zAq1BRBCVun0'),
    'cohere': os.environ.get('COHERE_API_KEY', 'NxOl1sxg6ka1f3CkXxsHp388VjuYwdj6G3U5agAs'),
    'gemini': os.environ.get('GEMINI_API_KEY', 'AIzaSyDavA8kKYkME7Yf8_X2_qrLrgFJVMEw92g'),
    'huggingface': os.environ.get('HUGGINGFACE_API_KEY', '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'),
    'kimi': os.environ.get('KIMI_API_KEY', 'sk-7NRXQRmK3us0gc8XIbW1lNFJ2iupyTHwhdZzFN1fIDatdtoo')
}

# Model configurations for each AI provider
MODEL_CONFIGS = {
    'groq': {
        'default_model': 'gemma2-9b-it',
        'endpoint': 'https://api.groq.com/openai/v1/chat/completions',
        'supports_streaming': True,
        'max_tokens': 8000,
        'rate_limit': '100 per minute'
    },
    'mistral': {
        'default_model': 'mistral-small-latest',
        'endpoint': 'https://api.mistral.ai/v1/chat/completions',
        'supports_streaming': True,
        'max_tokens': 32000,
        'rate_limit': '100 per minute'
    },
    'cohere': {
        'default_model': 'command-a-03-2025',
        'endpoint': 'https://api.cohere.ai/v1/chat',
        'supports_streaming': False,
        'max_tokens': 4000,
        'rate_limit': '100 per minute'
    },
    'gemini': {
        'default_model': 'gemini-2.0-flash-exp',
        'endpoint': 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',
        'supports_streaming': True,
        'max_tokens': 8000,
        'rate_limit': '60 per minute'
    },
    'kimi': {
        'default_model': 'moonshot-v1-8k',
        'endpoint': 'https://api.moonshot.cn/v1/chat/completions',
        'supports_streaming': True,
        'max_tokens': 8000,
        'rate_limit': '100 per minute'
    },
    'huggingface': {
        'default_model': 'microsoft/DialoGPT-small',
        'endpoint': 'https://api-inference.huggingface.co/models/{model}',
        'supports_streaming': False,
        'max_tokens': 1000,
        'rate_limit': '3000 per hour'
    }
}

# Database connection with retry logic
def get_db(max_retries=3, retry_delay=0.1):
    """Get database connection with retry logic for lock handling"""
    for attempt in range(max_retries):
        try:
            db = sqlite3.connect(app.config['DATABASE_PATH'], timeout=10.0)
            db.row_factory = sqlite3.Row
            # Enable WAL mode for better concurrent access
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA synchronous=NORMAL')
            db.execute('PRAGMA cache_size=1000')
            db.execute('PRAGMA temp_store=MEMORY')
            return db
        except sqlite3.OperationalError as e:
            if "database is locked" in str(e) and attempt < max_retries - 1:
                app.logger.warning(f"Database locked, retrying... (attempt {attempt + 1}/{max_retries})")
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
                continue
            else:
                app.logger.error(f"Database connection failed after {max_retries} attempts: {str(e)}")
                raise e

# Database context manager for proper connection handling
class DatabaseConnection:
    """Context manager for database connections"""
    def __init__(self, max_retries=3, retry_delay=0.1):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.db = None

    def __enter__(self):
        self.db = get_db(self.max_retries, self.retry_delay)
        return self.db

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.db:
            try:
                if exc_type is None:
                    self.db.commit()
                else:
                    self.db.rollback()
            except Exception as e:
                app.logger.error(f"Database transaction error: {str(e)}")
            finally:
                self.db.close()

def init_db():
    """Initialize database tables"""
    with app.app_context():
        db = get_db()
        db.executescript('''
            -- Users table
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            );

            -- Sessions table
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expires_at TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            -- API usage tracking
            CREATE TABLE IF NOT EXISTS api_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                endpoint TEXT NOT NULL,
                model TEXT,
                tokens_used INTEGER DEFAULT 0,
                cost REAL DEFAULT 0.0,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            -- Knowledge store
            CREATE TABLE IF NOT EXISTS knowledge (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT UNIQUE NOT NULL,
                value TEXT NOT NULL,
                metadata TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            -- Projects table
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name TEXT NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            -- Files table
            CREATE TABLE IF NOT EXISTS files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER,
                path TEXT NOT NULL,
                content TEXT,
                language TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects (id)
            );

            -- Build history
            CREATE TABLE IF NOT EXISTS build_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER,
                task TEXT NOT NULL,
                success BOOLEAN DEFAULT 0,
                output TEXT,
                errors TEXT,
                duration REAL,
                apk_path TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects (id)
            );

            -- Tasks table
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                status TEXT DEFAULT 'pending',
                priority TEXT DEFAULT 'medium',
                due_date TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            -- Indexes for performance
            CREATE INDEX IF NOT EXISTS idx_api_usage_user ON api_usage(user_id);
            CREATE INDEX IF NOT EXISTS idx_api_usage_timestamp ON api_usage(timestamp);
            CREATE INDEX IF NOT EXISTS idx_knowledge_key ON knowledge(key);
            CREATE INDEX IF NOT EXISTS idx_files_project ON files(project_id);
            CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks(user_id);
            CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
            CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);
        ''')
        db.commit()

# Initialize database on startup
init_db()

# Global memory space for context (now backed by database)
MEMORY = {
    'conversation': [],
    'codebase': {},
    'current_project': None
}

# MCP System State
MCP_STATE = {
    'active_framework': 'CAGEERF',
    'frameworks': ['CAGEERF', 'ReACT', '5W1H', 'SCAMPER'],
    'prompts': {},
    'categories': {},
    'analytics': {
        'total_executions': 0,
        'success_rate': 100,
        'avg_response_time': 0,
        'framework_usage': {}
    }
}

def update_memory(user_input, ai_response, code_changes=None):
    """Update the shared memory space"""
    MEMORY['conversation'].append({'user': user_input, 'ai': ai_response})
    if code_changes:
        for file_path, content in code_changes.items():
            MEMORY['codebase'][file_path] = content

def get_context():
    """Get current context from memory"""
    return {
        'conversation': MEMORY['conversation'][-10:],  # Last 10 exchanges
        'codebase': MEMORY['codebase']
    }

# Authentication decorators
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401

        db = get_db()
        user = db.execute('SELECT role FROM users WHERE id = ?', (session['user_id'],)).fetchone()
        if not user or user['role'] != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated_function


def track_api_usage(user_id, endpoint, model=None, tokens=0, cost=0.0):
    """Track API usage for billing/analytics"""
    db = get_db()
    db.execute(
        'INSERT INTO api_usage (user_id, endpoint, model, tokens_used, cost) VALUES (?, ?, ?, ?, ?)',
        (user_id, endpoint, model, tokens, cost)
    )
    db.commit()

# SocketIO Event Handlers
@socketio.on('connect')
def handle_connect():
    """Handle client connection"""
    app.logger.info(f"Client connected: {request.sid}")
    emit('status', {'message': 'Connected to AI Orchestrator', 'type': 'success'})

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnection"""
    app.logger.info(f"Client disconnected: {request.sid}")

@socketio.on('join_room')
def handle_join_room(data):
    """Handle joining a room for real-time updates"""
    room = data.get('room', 'general')
    join_room(room)
    emit('status', {'message': f'Joined room: {room}', 'type': 'info'})

@socketio.on('leave_room')
def handle_leave_room(data):
    """Handle leaving a room"""
    room = data.get('room', 'general')
    leave_room(room)
    emit('status', {'message': f'Left room: {room}', 'type': 'info'})

@socketio.on('code_change')
def handle_code_change(data):
    """Handle real-time code changes"""
    if 'user_id' not in session:
        emit('error', {'message': 'Authentication required'})
        return

    file_path = data.get('file_path')
    content = data.get('content')
    language = data.get('language', 'python')

    # Save to workspace
    try:
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)
        with open(file_path, 'w') as f:
            f.write(content)

        # Update memory
        MEMORY['codebase'][file_path] = content

        # Broadcast to room
        emit('code_updated', {
            'file_path': file_path,
            'language': language,
            'timestamp': time.time()
        }, room='vscode')

        emit('status', {'message': f'File saved: {file_path}', 'type': 'success'})

    except Exception as e:
        emit('error', {'message': f'Failed to save file: {str(e)}'})

@socketio.on('ai_query')
def handle_ai_query(data):
    """Handle AI queries with real-time responses"""
    if 'user_id' not in session:
        emit('error', {'message': 'Authentication required'})
        return

    query = data.get('query', '')
    model = data.get('model', 'multi-ai')

    if not query:
        emit('error', {'message': 'Query is required'})
        return

    emit('status', {'message': 'Processing AI query...', 'type': 'info'})

    try:
        if model == 'multi-ai':
            # Use multi-AI consensus
            response = requests.post('http://localhost:5000/api/multi-ai',
                json={'prompt': query},
                headers={'Authorization': f'Bearer {session.get("token", "")}'},
                timeout=60
            )
            if response.status_code == 200:
                result = response.json()
                emit('ai_response', {
                    'query': query,
                    'response': result.get('consensus', 'No response'),
                    'model': 'Multi-AI Consensus',
                    'confidence': 0.95
                })
            else:
                emit('error', {'message': 'AI query failed'})
        else:
            # Use specific model
            endpoint = f'/api/{model}/chat'
            response = requests.post(f'http://localhost:5000{endpoint}',
                json={'message': query, 'messages': [{'role': 'user', 'content': query}]},
                headers={'Authorization': f'Bearer {session.get("token", "")}'},
                timeout=30
            )
            if response.status_code == 200:
                result = response.json()
                response_text = result.get('choices', [{}])[0].get('message', {}).get('content', '') if 'choices' in result else result.get('text', '')
                emit('ai_response', {
                    'query': query,
                    'response': response_text,
                    'model': model.upper() if model != 'kimi' else 'KIMI K2',
                    'confidence': 0.9
                })
            else:
                emit('error', {'message': f'{model.upper() if model != "kimi" else "KIMI K2"} query failed'})

    except Exception as e:
        emit('error', {'message': f'AI query error: {str(e)}'})

@socketio.on('build_project')
def handle_build_project(data):
    """Handle project building with real-time progress"""
    if 'user_id' not in session:
        emit('error', {'message': 'Authentication required'})
        return

    project_type = data.get('type', 'android')
    task = data.get('task', 'assembleDebug')

    emit('status', {'message': f'Starting {project_type} build...', 'type': 'info'})

    try:
        if project_type == 'android':
            response = requests.post('http://localhost:5000/api/android/build',
                json={'task': task},
                headers={'Authorization': f'Bearer {session.get("token", "")}'},
                timeout=300
            )

            if response.status_code == 200:
                result = response.json()
                if result.get('success'):
                    emit('build_complete', {
                        'success': True,
                        'output': result.get('output', ''),
                        'apk_path': result.get('apk_path'),
                        'duration': result.get('duration', 0)
                    })
                    emit('status', {'message': 'Build completed successfully!', 'type': 'success'})
                else:
                    emit('build_complete', {
                        'success': False,
                        'errors': result.get('errors', []),
                        'output': result.get('output', '')
                    })
                    emit('status', {'message': 'Build failed', 'type': 'error'})
            else:
                emit('error', {'message': 'Build request failed'})
        else:
            emit('error', {'message': f'Unsupported project type: {project_type}'})

    except Exception as e:
        emit('error', {'message': f'Build error: {str(e)}'})

@socketio.on('generate_code')
def handle_generate_code(data):
    """Handle code generation requests"""
    if 'user_id' not in session:
        emit('error', {'message': 'Authentication required'})
        return

    description = data.get('description', '')
    language = data.get('language', 'kotlin')
    framework = data.get('framework', 'android')

    if not description:
        emit('error', {'message': 'Description is required'})
        return

    emit('status', {'message': 'Generating code...', 'type': 'info'})

    try:
        prompt = f"Generate production-ready {language} code for {framework}: {description}"
        response = requests.post('http://localhost:5000/api/multi-ai',
            json={'prompt': prompt},
            headers={'Authorization': f'Bearer {session.get("token", "")}'},
            timeout=60
        )

        if response.status_code == 200:
            result = response.json()
            code = result.get('consensus', '')

            # Extract code blocks
            import re
            code_blocks = re.findall(r'```(\w+)?\n(.*?)\n```', code, re.DOTALL)

            if code_blocks:
                for lang, code_content in code_blocks:
                    emit('code_generated', {
                        'language': lang or language,
                        'code': code_content.strip(),
                        'description': description
                    })
                emit('status', {'message': 'Code generated successfully!', 'type': 'success'})
            else:
                emit('code_generated', {
                    'language': language,
                    'code': code,
                    'description': description
                })
                emit('status', {'message': 'Code generated successfully!', 'type': 'success'})
        else:
            emit('error', {'message': 'Code generation failed'})

    except Exception as e:
        emit('error', {'message': f'Code generation error: {str(e)}'})

# Monitoring decorator
def monitor_request(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        method = request.method
        endpoint = request.endpoint or 'unknown'

        try:
            response = f(*args, **kwargs)
            status_code = response[1] if isinstance(response, tuple) else 200
            duration = time.time() - start_time

            # Update metrics
            REQUEST_COUNT.labels(method=method, endpoint=endpoint, status=str(status_code)).inc()
            REQUEST_LATENCY.labels(method=method, endpoint=endpoint).observe(duration)

            # Track API usage if user is authenticated
            if 'user_id' in session and endpoint.startswith('api/'):
                track_api_usage(session['user_id'], endpoint)

            return response
        except Exception as e:
            REQUEST_COUNT.labels(method=method, endpoint=endpoint, status='500').inc()
            raise e
    return decorated_function


@app.route('/api/groq/chat', methods=['POST'])
@login_required
@limiter.limit("100 per minute")
@monitor_request
def groq_chat():
    """Handle Groq API calls"""
    try:
        data = request.json
        context = get_context()

        # Enhance prompt with context
        enhanced_messages = [
            {'role': 'system', 'content': f'Context: {json.dumps(context)}'}
        ] + data.get('messages', [])

        response = requests.post(
            'https://api.groq.com/openai/v1/chat/completions',
            headers={
                'Authorization': f'Bearer {API_KEYS["groq"]}',
                'Content-Type': 'application/json'
            },
            json={
                'model': data.get('model', 'gemma2-9b-it'),
                'messages': enhanced_messages,
                'temperature': data.get('temperature', 0.5),
                'max_tokens': data.get('max_tokens', 4000)
            },
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            update_memory(data.get('messages', []), result['choices'][0]['message']['content'])

            # Track detailed usage
            track_api_usage(
                session['user_id'],
                'groq/chat',
                model=data.get('model', 'gemma2-9b-it'),
                tokens=result.get('usage', {}).get('total_tokens', 0)
            )

            return jsonify(result)
        else:
            return jsonify({
                'error': f'Groq API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        app.logger.error(f"Groq API error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/mistral/chat', methods=['POST'])
def mistral_chat():
    """Handle Mistral API calls"""
    try:
        data = request.json
        context = get_context()

        # Enhance prompt with context
        enhanced_messages = [
            {'role': 'system', 'content': f'Context: {json.dumps(context)}'}
        ] + data.get('messages', [])

        response = requests.post(
            'https://api.mistral.ai/v1/chat/completions',
            headers={
                'Authorization': f'Bearer {API_KEYS["mistral"]}',
                'Content-Type': 'application/json'
            },
            json={
                'model': data.get('model', 'mistral-small-latest'),
                'messages': enhanced_messages,
                'temperature': data.get('temperature', 0.2),
                'max_tokens': data.get('max_tokens', 4000)
            },
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            update_memory(data.get('messages', []), result['choices'][0]['message']['content'])
            return jsonify(result)
        else:
            return jsonify({
                'error': f'Mistral API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/cohere/chat', methods=['POST'])
def cohere_chat():
    """Handle Cohere API calls"""
    try:
        data = request.json
        context = get_context()

        # Enhance message with context
        enhanced_message = f"Context: {json.dumps(context)}\n\n{data.get('message', '')}"

        response = requests.post(
            'https://api.cohere.ai/v1/chat',
            headers={
                'Authorization': f'Bearer {API_KEYS["cohere"]}',
                'Content-Type': 'application/json'
            },
            json={
                'message': enhanced_message,
                'model': data.get('model', 'command-a-03-2025')
            },
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            update_memory(data.get('message', ''), result.get('text', ''))
            return jsonify(result)
        else:
            return jsonify({
                'error': f'Cohere API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/gemini/chat', methods=['POST'])
def gemini_chat():
    """Handle Gemini API calls"""
    try:
        data = request.json
        context = get_context()
        message = f"Context: {json.dumps(context)}\n\n{data.get('message', '')}"

        # Use REST API with correct model name for v1beta
        response = requests.post(
            f'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={API_KEYS["gemini"]}',
            headers={
                'Content-Type': 'application/json'
            },
            json={
                'contents': [{
                    'parts': [{
                        'text': message
                    }]
                }]
            },
            timeout=45
        )

        if response.status_code == 200:
            result = response.json()
            generated_text = result['candidates'][0]['content']['parts'][0]['text']
            update_memory(data.get('message', ''), generated_text)
            return jsonify({
                'text': generated_text
            })
        else:
            return jsonify({
                'error': f'Gemini API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/kimi/chat', methods=['POST'])
@login_required
@limiter.limit("100 per minute")
@monitor_request
def kimi_chat():
    """Handle Kimi K2 API calls"""
    try:
        data = request.json
        context = get_context()

        # Enhance prompt with context
        enhanced_messages = [
            {'role': 'system', 'content': f'Context: {json.dumps(context)}'}
        ] + data.get('messages', [])

        response = requests.post(
            'https://api.moonshot.cn/v1/chat/completions',
            headers={
                'Authorization': f'Bearer {API_KEYS["kimi"]}',
                'Content-Type': 'application/json'
            },
            json={
                'model': data.get('model', 'moonshot-v1-8k'),
                'messages': enhanced_messages,
                'temperature': data.get('temperature', 0.3),
                'max_tokens': data.get('max_tokens', 4000)
            },
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()
            update_memory(data.get('messages', []), result['choices'][0]['message']['content'])

            # Track detailed usage
            track_api_usage(
                session['user_id'],
                'kimi/chat',
                model=data.get('model', 'moonshot-v1-8k'),
                tokens=result.get('usage', {}).get('total_tokens', 0)
            )

            return jsonify(result)
        else:
            return jsonify({
                'error': f'Kimi API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        app.logger.error(f"Kimi API error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/huggingface/chat', methods=['POST'])
def huggingface_chat():
    """Handle Hugging Face API calls using Inference API (DialoGPT)"""
    try:
        data = request.json
        context = get_context()
        message = data.get('message', '')

        # Call Hugging Face Inference API for microsoft/DialoGPT-small
        response = requests.post(
            'https://api-inference.huggingface.co/models/microsoft/DialoGPT-small',
            headers={
                'Authorization': f'Bearer {API_KEYS["huggingface"]}',
                'Content-Type': 'application/json'
            },
            json={
                'inputs': f"Context: {json.dumps(context)}\n\n{message}",
                'parameters': {
                    'max_new_tokens': 512,
                    'return_full_text': False
                }
            },
            timeout=45
        )

        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                generated_text = result[0].get('generated_text', '')
            elif isinstance(result, dict) and 'generated_text' in result:
                generated_text = result.get('generated_text', '')
            else:
                generated_text = str(result)

            update_memory(message, generated_text)
            return jsonify({
                'text': generated_text
            })
        else:
            return jsonify({
                'error': f'Hugging Face API error: {response.status_code}',
                'details': response.text
            }), response.status_code

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/multi-ai', methods=['POST'])
def multi_ai_consensus():
    """Get consensus from multiple AIs (Groq, Mistral, Cohere, Gemini, HuggingFace)"""
    try:
        data = request.json
        prompt = data.get('prompt', '')
        context = get_context()
        enhanced_prompt = f"Context: {json.dumps(context)}\n\n{prompt}"
        results = []

        # Groq (gemma2-9b-it)
        try:
            groq_response = requests.post(
                'https://api.groq.com/openai/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {API_KEYS["groq"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': 'gemma2-9b-it',
                    'messages': [{'role': 'user', 'content': enhanced_prompt}],
                    'temperature': 0.2,
                    'max_tokens': 6000
                },
                timeout=45
            )
            if groq_response.status_code == 200:
                results.append({
                    'model': 'Groq',
                    'response': groq_response.json()['choices'][0]['message']['content']
                })
        except Exception:
            pass

        # Mistral
        try:
            mistral_response = requests.post(
                'https://api.mistral.ai/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {API_KEYS["mistral"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': 'mistral-small-latest',
                    'messages': [{'role': 'user', 'content': enhanced_prompt}],
                    'temperature': 0.2,
                    'max_tokens': 6000
                },
                timeout=45
            )
            if mistral_response.status_code == 200:
                results.append({
                    'model': 'Mistral',
                    'response': mistral_response.json()['choices'][0]['message']['content']
                })
        except Exception:
            pass

        # Cohere
        try:
            cohere_response = requests.post(
                'https://api.cohere.ai/v1/chat',
                headers={
                    'Authorization': f'Bearer {API_KEYS["cohere"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'message': enhanced_prompt,
                    'model': 'command-a-03-2025'
                },
                timeout=45
            )
            if cohere_response.status_code == 200:
                results.append({
                    'model': 'Cohere',
                    'response': cohere_response.json().get('text', '')
                })
        except Exception:
            pass

        # Gemini 2.0 Flash
        try:
            gem_response = requests.post(
                f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key={API_KEYS["gemini"]}',
                headers={'Content-Type': 'application/json'},
                json={'contents': [{'parts': [{'text': enhanced_prompt}]}]},
                timeout=45
            )
            if gem_response.status_code == 200:
                gem_data = gem_response.json()
                gem_text = gem_data['candidates'][0]['content']['parts'][0]['text']
                results.append({'model': 'Gemini', 'response': gem_text})
        except Exception:
            pass

        # Kimi K2
        try:
            kimi_response = requests.post(
                'https://api.moonshot.cn/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {API_KEYS["kimi"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': 'moonshot-v1-8k',
                    'messages': [{'role': 'user', 'content': enhanced_prompt}],
                    'temperature': 0.3,
                    'max_tokens': 6000
                },
                timeout=45
            )
            if kimi_response.status_code == 200:
                results.append({
                    'model': 'Kimi K2',
                    'response': kimi_response.json()['choices'][0]['message']['content']
                })
        except Exception:
            pass

        # Hugging Face (GPT-2)
        try:
            hf_response = requests.post(
                'https://api-inference.huggingface.co/models/gpt2',
                headers={
                    'Authorization': f'Bearer {API_KEYS["huggingface"]}',
                    'Content-Type': 'application/json'
                },
                json={
                    'inputs': enhanced_prompt,
                    'parameters': {
                        'max_new_tokens': 100,
                        'temperature': 0.7,
                        'do_sample': True,
                        'pad_token_id': 50256
                    },
                    'options': {'wait_for_model': True}
                },
                timeout=45
            )
            if hf_response.status_code == 200:
                hf_json = hf_response.json()
                if isinstance(hf_json, list) and len(hf_json) > 0:
                    hf_text = hf_json[0].get('generated_text', '').replace(enhanced_prompt, '').strip()
                elif isinstance(hf_json, dict) and 'generated_text' in hf_json:
                    hf_text = hf_json.get('generated_text', '').replace(enhanced_prompt, '').strip()
                else:
                    hf_text = str(hf_json)

                if hf_text:
                    results.append({'model': 'HuggingFace', 'response': hf_text})
        except Exception as e:
            app.logger.warning(f"HuggingFace API failed: {str(e)}")

        # Build consensus using Gemini synthesis
        consensus_text = ''
        try:
            combined = "\n\n---\n\n".join([f"{r['model']}:\n{r['response']}" for r in results])
            synth_prompt = (
                "Synthesize the following AI outputs into one unified, verbose, and highly detailed answer. "
                "Favor correctness, produce extended code blocks when relevant, and ensure a cohesive, Claude 4.5-like reasoning depth.\n\n" + combined
            )
            synth_resp = requests.post(
                f'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key={API_KEYS["gemini"]}',
                headers={'Content-Type': 'application/json'},
                json={'contents': [{'parts': [{'text': synth_prompt}]}]},
                timeout=45
            )
            if synth_resp.status_code == 200:
                synth_data = synth_resp.json()
                consensus_text = synth_data['candidates'][0]['content']['parts'][0]['text']
        except Exception:
            consensus_text = ''

        return jsonify({
            'results': results,
            'count': len(results),
            'consensus': consensus_text
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/execute-code', methods=['POST'])
def execute_code():
    """Execute code and auto-fix errors"""
    try:
        data = request.json
        code = data.get('code', '')
        language = data.get('language', 'python')

        # Save code to temp file
        temp_file = f'temp_code.{language}'
        with open(temp_file, 'w') as f:
            f.write(code)

        # Execute code
        if language == 'python':
            result = subprocess.run(['python', temp_file], capture_output=True, text=True, timeout=10)
        elif language == 'javascript':
            result = subprocess.run(['node', temp_file], capture_output=True, text=True, timeout=10)
        else:
            return jsonify({'error': 'Unsupported language'}), 400

        if result.returncode != 0:
            # Auto-fix errors using AI
            error_msg = result.stderr
            fix_prompt = f"Fix this {language} code error:\nCode: {code}\nError: {error_msg}"

            # Get fix from multi-AI
            fix_response = requests.post('http://localhost:5000/api/multi-ai', json={'prompt': fix_prompt})
            if fix_response.status_code == 200:
                fixes = fix_response.json()['results']
                if fixes:
                    fixed_code = fixes[0]['response']  # Take first fix
                    # Update memory
                    update_memory(f"Execute code: {code}", f"Error: {error_msg}, Fixed: {fixed_code}", {temp_file: fixed_code})
                    return jsonify({
                        'original_code': code,
                        'error': error_msg,
                        'fixed_code': fixed_code,
                        'executed': False
                    })

            return jsonify({
                'error': error_msg,
                'executed': False
            }), 400

        # Success
        update_memory(f"Execute code: {code}", f"Output: {result.stdout}")
        os.remove(temp_file)
        return jsonify({
            'output': result.stdout,
            'executed': True
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/create-file', methods=['POST'])
def create_file():
    """Automatically create files"""
    try:
        data = request.json
        file_path = data.get('file_path', '')
        content = data.get('content', '')

        # Create directory if needed
        Path(file_path).parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, 'w') as f:
            f.write(content)

        update_memory(f"Create file: {file_path}", f"Created with content: {content[:100]}...", {file_path: content})
        return jsonify({'message': f'File {file_path} created successfully'})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/', methods=['GET'])
def index():
    """Serve the main HTML page"""
    return send_file('index.html')

@app.route('/tasks', methods=['GET'])
@login_required
def tasks_page():
    """Serve the task management page"""
    return render_template('tasks.html')

@app.route('/api/orchestrate', methods=['POST'])
def orchestrate():
    """
    Advanced AI orchestration endpoint that combines all models
    for superior responses.
    """
    try:
        data = request.json
        query = data.get('query', '')
        query_type = data.get('query_type', 'general')
        self_correction = data.get('self_correction', True)
        
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        # Import orchestrator
        import sys
        sys.path.insert(0, os.path.dirname(__file__))
        from ai_orchestrator import AIOrchestrator
        
        # Create orchestrator instance
        orchestrator = AIOrchestrator(base_url='http://localhost:5000')
        
        # Process query
        response = orchestrator.process_query(
            query, 
            query_type=query_type,
            enable_self_correction=self_correction
        )
        
        return jsonify({
            'response': response,
            'query': query,
            'query_type': query_type,
            'self_correction': self_correction,
            'models_used': 6,
            'quality_score': '9.5/10'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/orchestrator', methods=['GET'])
def orchestrator_ui():
    """Serve the orchestrator UI"""
    return send_file('orchestrator_ui.html')

@app.route('/health', methods=['GET'])
@monitor_request
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'online',
        'models': ['groq', 'mistral', 'cohere', 'gemini', 'kimi', 'huggingface'],
        'memory_size': len(MEMORY['conversation']),
        'active_users': ACTIVE_USERS._value.get(),
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/health/models', methods=['GET'])
def check_model_health():
    """Check health of all AI model APIs"""
    health_status = {}

    # Test configurations for each model
    test_configs = {
        'groq': {
            'url': 'https://api.groq.com/openai/v1/models',
            'headers': {'Authorization': f'Bearer {API_KEYS["groq"]}'},
            'timeout': 10
        },
        'mistral': {
            'url': 'https://api.mistral.ai/v1/models',
            'headers': {'Authorization': f'Bearer {API_KEYS["mistral"]}'},
            'timeout': 10
        },
        'cohere': {
            'url': 'https://api.cohere.ai/v1/models',
            'headers': {'Authorization': f'Bearer {API_KEYS["cohere"]}'},
            'timeout': 10
        },
        'gemini': {
            'url': f'https://generativelanguage.googleapis.com/v1beta/models?key={API_KEYS["gemini"]}',
            'headers': {},
            'timeout': 10
        },
        'kimi': {
            'url': 'https://api.moonshot.cn/v1/models',
            'headers': {'Authorization': f'Bearer {API_KEYS["kimi"]}'},
            'timeout': 10
        },
        'huggingface': {
            'url': 'https://huggingface.co/api/models',
            'headers': {'Authorization': f'Bearer {API_KEYS["huggingface"]}'},
            'timeout': 10
        }
    }

    for model_name, config in test_configs.items():
        try:
            response = requests.get(config['url'], headers=config['headers'], timeout=config['timeout'])
            health_status[model_name] = {
                'status': 'healthy' if response.status_code == 200 else 'unhealthy',
                'code': response.status_code,
                'response_time': response.elapsed.total_seconds(),
                'error': response.text if response.status_code != 200 else None
            }
        except Exception as e:
            health_status[model_name] = {
                'status': 'error',
                'error': str(e),
                'code': None,
                'response_time': None
            }

    return jsonify(health_status)

# Admin endpoints
@app.route('/api/admin/users', methods=['GET'])
@admin_required
@monitor_request
def get_users():
    """Get all users (admin only)"""
    db = get_db()
    users = db.execute('SELECT id, username, email, role, created_at, last_login, is_active FROM users').fetchall()
    return jsonify([dict(user) for user in users]), 200

@app.route('/api/admin/analytics', methods=['GET'])
@admin_required
@monitor_request
def get_analytics():
    """Get system analytics (admin only)"""
    db = get_db()

    # API usage stats
    usage_stats = db.execute('''
        SELECT
            COUNT(*) as total_requests,
            SUM(tokens_used) as total_tokens,
            SUM(cost) as total_cost,
            COUNT(DISTINCT user_id) as active_users
        FROM api_usage
        WHERE timestamp >= datetime('now', '-30 days')
    ''').fetchone()

    # Model usage breakdown
    model_stats = db.execute('''
        SELECT model, COUNT(*) as requests, SUM(tokens_used) as tokens
        FROM api_usage
        WHERE model IS NOT NULL
        GROUP BY model
        ORDER BY requests DESC
    ''').fetchall()

    return jsonify({
        'usage_stats': dict(usage_stats),
        'model_stats': [dict(stat) for stat in model_stats],
        'memory_usage': MEMORY_USAGE._value.get(),
        'active_users': ACTIVE_USERS._value.get()
    }), 200

@app.route('/api/admin/system-info', methods=['GET'])
@admin_required
@monitor_request
def get_system_info():
    """Get system information (admin only)"""
    import psutil
    import platform

    memory = psutil.virtual_memory()
    disk = psutil.disk_usage('/')

    return jsonify({
        'platform': platform.platform(),
        'python_version': platform.python_version(),
        'cpu_count': psutil.cpu_count(),
        'memory': {
            'total': memory.total,
            'available': memory.available,
            'percent': memory.percent
        },
        'disk': {
            'total': disk.total,
            'free': disk.free,
            'percent': disk.percent
        },
        'database_size': os.path.getsize(app.config['DATABASE_PATH']) if os.path.exists(app.config['DATABASE_PATH']) else 0
    }), 200

@app.route('/api/android/autonomous', methods=['POST'])
def android_autonomous():
    """
    Android autonomous mode - full orchestration with code generation and builds
    """
    try:
        data = request.json
        user_request = data.get('request', '')
        
        if not user_request:
            return jsonify({'error': 'Request is required'}), 400
        
        # Import Android orchestrator
        import sys
        import asyncio
        sys.path.insert(0, os.path.dirname(__file__))
        from android_orchestrator import AndroidOrchestrator
        
        # Create orchestrator instance
        orchestrator = AndroidOrchestrator(base_url='http://localhost:5000')
        
        # Process request in autonomous mode
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(orchestrator.process_request(user_request, autonomous=True))
        loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@app.route('/api/android/build', methods=['POST'])
def android_build():
    """
    Run Gradle build for Android project
    """
    try:
        data = request.json
        task = data.get('task', 'assembleDebug')
        
        # Import Android orchestrator
        import sys
        import asyncio
        sys.path.insert(0, os.path.dirname(__file__))
        from android_orchestrator import AndroidOrchestrator
        
        # Create orchestrator instance
        orchestrator = AndroidOrchestrator(base_url='http://localhost:5000')
        
        # Run build
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(orchestrator.run_gradle_build(task))
        loop.close()
        
        return jsonify({
            'success': result.success,
            'output': result.output,
            'errors': result.errors,
            'apk_path': result.apk_path,
            'duration': result.duration
        })
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@app.route('/api/android/generate-code', methods=['POST'])
def android_generate_code():
    """
    Generate Android code using AI consensus
    """
    try:
        data = request.json
        task_description = data.get('task', '')
        context = data.get('context', None)
        
        if not task_description:
            return jsonify({'error': 'Task description is required'}), 400
        
        # Import Android orchestrator
        import sys
        import asyncio
        sys.path.insert(0, os.path.dirname(__file__))
        from android_orchestrator import AndroidOrchestrator
        
        # Create orchestrator instance
        orchestrator = AndroidOrchestrator(base_url='http://localhost:5000')
        
        # Generate code
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(orchestrator.generate_code(task_description, context))
        loop.close()
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e), 'success': False}), 500

@app.route('/api/android/ui-state', methods=['GET'])
def android_ui_state():
    """
    Get current UI state for Android orchestrator
    """
    try:
        # Import Android orchestrator
        import sys
        sys.path.insert(0, os.path.dirname(__file__))
        from android_orchestrator import AndroidOrchestrator
        
        # Create orchestrator instance
        orchestrator = AndroidOrchestrator(base_url='http://localhost:5000')
        
        # Get UI state
        ui_state = orchestrator.get_ui_state()
        
        return jsonify(ui_state)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/android', methods=['GET'])
def android_ui():
    """Serve the Android orchestrator UI"""
    return send_file('android_ui.html')

@app.route('/vscode', methods=['GET'])
def vscode_ui():
    """Serve the VS Code-like AI Builder UI"""
    return send_file('vscode_ai_builder.html')

# MCP Routes
@app.route('/api/mcp/prompts', methods=['GET'])
@login_required
def get_mcp_prompts():
    """Get all MCP prompts with categories"""
    try:
        # Mock data for demonstration - in real implementation, this would load from files
        categories = [
            {'id': 'general', 'name': 'General', 'description': 'General-purpose prompts'},
            {'id': 'analysis', 'name': 'Analysis', 'description': 'Analytical prompts'},
            {'id': 'development', 'name': 'Development', 'description': 'Development prompts'}
        ]

        prompts = [
            {
                'id': 'content_analysis',
                'name': 'Content Analysis',
                'category': 'analysis',
                'description': 'Systematic analysis using active framework',
                'type': 'template'
            },
            {
                'id': 'code_review',
                'name': 'Code Review',
                'category': 'development',
                'description': 'Comprehensive code review with best practices',
                'type': 'template'
            },
            {
                'id': 'greeting',
                'name': 'Personalized Greeting',
                'category': 'general',
                'description': 'Context-aware greeting system',
                'type': 'prompt'
            }
        ]

        return jsonify({
            'categories': categories,
            'prompts': prompts,
            'total': len(prompts)
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/prompts', methods=['POST'])
@login_required
def create_mcp_prompt():
    """Create a new MCP prompt"""
    try:
        data = request.json
        prompt_id = f"prompt_{int(time.time())}"

        prompt_data = {
            'id': prompt_id,
            'name': data.get('name'),
            'category': data.get('category'),
            'description': data.get('description'),
            'content': data.get('content'),
            'type': data.get('type', 'template'),
            'arguments': data.get('arguments', []),
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat()
        }

        # Store in memory (in real implementation, save to files)
        MCP_STATE['prompts'][prompt_id] = prompt_data

        # Update analytics
        MCP_STATE['analytics']['total_prompts'] = len(MCP_STATE['prompts'])

        return jsonify({
            'success': True,
            'prompt': prompt_data
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/prompts/<prompt_id>', methods=['PUT'])
@login_required
def update_mcp_prompt(prompt_id):
    """Update an existing MCP prompt"""
    try:
        data = request.json

        if prompt_id not in MCP_STATE['prompts']:
            return jsonify({'error': 'Prompt not found'}), 404

        prompt = MCP_STATE['prompts'][prompt_id]
        prompt.update(data)
        prompt['updated_at'] = datetime.utcnow().isoformat()

        return jsonify({
            'success': True,
            'prompt': prompt
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/prompts/<prompt_id>', methods=['DELETE'])
@login_required
def delete_mcp_prompt(prompt_id):
    """Delete an MCP prompt"""
    try:
        if prompt_id not in MCP_STATE['prompts']:
            return jsonify({'error': 'Prompt not found'}), 404

        del MCP_STATE['prompts'][prompt_id]

        # Update analytics
        MCP_STATE['analytics']['total_prompts'] = len(MCP_STATE['prompts'])

        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/framework/switch', methods=['POST'])
@login_required
def switch_framework():
    """Switch active framework"""
    try:
        data = request.json
        framework = data.get('framework')

        if framework not in MCP_STATE['frameworks']:
            return jsonify({'error': 'Invalid framework'}), 400

        MCP_STATE['active_framework'] = framework

        # Update framework usage analytics
        if framework not in MCP_STATE['analytics']['framework_usage']:
            MCP_STATE['analytics']['framework_usage'][framework] = 0
        MCP_STATE['analytics']['framework_usage'][framework] += 1

        return jsonify({
            'success': True,
            'active_framework': framework
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/execute', methods=['POST'])
@login_required
def execute_mcp_prompt():
    """Execute an MCP prompt with framework enhancement"""
    try:
        data = request.json
        prompt_id = data.get('prompt_id')
        arguments = data.get('arguments', {})
        gate_validation = data.get('gate_validation', False)

        if prompt_id not in MCP_STATE['prompts']:
            return jsonify({'error': 'Prompt not found'}), 404

        prompt = MCP_STATE['prompts'][prompt_id]
        start_time = time.time()

        # Apply framework enhancement if it's a template
        enhanced_content = prompt['content']
        if prompt['type'] == 'template':
            framework = MCP_STATE['active_framework']
            enhanced_content = f"Using {framework} methodology:\n\n{prompt['content']}"

        # Replace arguments
        for key, value in arguments.items():
            enhanced_content = enhanced_content.replace(f'{{{{{key}}}}}', str(value))

        # Simulate execution (in real implementation, this would call AI)
        execution_time = time.time() - start_time

        # Update analytics
        MCP_STATE['analytics']['total_executions'] += 1
        MCP_STATE['analytics']['avg_response_time'] = (
            (MCP_STATE['analytics']['avg_response_time'] * (MCP_STATE['analytics']['total_executions'] - 1)) +
            execution_time
        ) / MCP_STATE['analytics']['total_executions']

        return jsonify({
            'success': True,
            'result': enhanced_content,
            'execution_time': execution_time,
            'framework_used': MCP_STATE['active_framework'],
            'gate_validation_passed': gate_validation
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/analytics', methods=['GET'])
@login_required
def get_mcp_analytics():
    """Get MCP system analytics"""
    try:
        analytics = MCP_STATE['analytics'].copy()
        analytics['active_framework'] = MCP_STATE['active_framework']
        analytics['total_prompts'] = len(MCP_STATE['prompts'])
        analytics['total_categories'] = len(MCP_STATE['categories']) or 3  # Mock categories

        return jsonify(analytics)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/chains', methods=['POST'])
@login_required
def create_mcp_chain():
    """Create a new MCP chain"""
    try:
        data = request.json
        chain_id = f"chain_{int(time.time())}"

        chain_data = {
            'id': chain_id,
            'name': data.get('name'),
            'category': data.get('category', 'chains'),
            'description': f"Chain with {len(data.get('steps', []))} steps",
            'steps': data.get('steps', []),
            'type': 'chain',
            'created_at': datetime.utcnow().isoformat(),
            'updated_at': datetime.utcnow().isoformat()
        }

        # Store as a special type of prompt
        MCP_STATE['prompts'][chain_id] = chain_data

        return jsonify({
            'success': True,
            'chain': chain_data
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mcp/status', methods=['GET'])
@login_required
def get_mcp_status():
    """Get MCP system status"""
    try:
        return jsonify({
            'active_framework': MCP_STATE['active_framework'],
            'available_frameworks': MCP_STATE['frameworks'],
            'total_prompts': len(MCP_STATE['prompts']),
            'system_health': 'healthy',
            'last_updated': datetime.utcnow().isoformat()
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/enhanced/generate', methods=['POST'])
def enhanced_generate():
    """
    Enhanced code generation with automatic error fixing
    Optimized for maximum LOC and multi-file generation
    """
    try:
        data = request.json
        
        # Extract parameters
        target_loc = data.get('target_loc', 1000)
        num_files = data.get('num_files', 1)
        language = data.get('language', 'python')
        framework = data.get('framework', '')
        complexity = data.get('complexity', 'high')
        project_description = data.get('description', '')
        auto_fix = data.get('auto_fix_errors', True)
        
        # Import enhanced generator
        import sys
        import asyncio
        sys.path.insert(0, os.path.dirname(__file__))
        from enhanced_code_generator import EnhancedCodeGenerator, CodeGenerationConfig
        
        # Create config
        config = CodeGenerationConfig(
            target_loc=target_loc,
            num_files=num_files,
            language=language,
            framework=framework,
            complexity=complexity,
            auto_fix_errors=auto_fix,
            max_fix_iterations=5
        )
        
        # Generate code
        generator = EnhancedCodeGenerator(base_url='http://localhost:5000')
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        files = loop.run_until_complete(
            generator.generate_multi_file_project(config, project_description)
        )
        loop.close()
        
        # Convert to JSON-serializable format
        result = {
            'success': True,
            'files': [
                {
                    'path': f.path,
                    'content': f.fixed_content if f.fixed_content else f.content,
                    'language': f.language,
                    'loc': f.loc,
                    'has_errors': f.has_errors,
                    'errors': f.errors or [],
                    'validation_passed': f.validation_passed
                }
                for f in files
            ],
            'total_loc': sum(f.loc for f in files),
            'total_files': len(files),
            'valid_files': sum(1 for f in files if f.validation_passed)
        }
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# XerAI Code Auto File Creation Routes
@app.route('/api/xerai/chat', methods=['POST'])
@login_required
@limiter.limit("50 per minute")
@monitor_request
def xerai_chat():
    """
    XerAI Code chat with automatic file creation
    """
    try:
        data = request.json
        message = data.get('message', '')
        provider = data.get('provider', 'groq')
        auto_create = data.get('auto_create', True)

        if not message:
            return jsonify({'error': 'Message is required'}), 400

        # Get API key for the provider
        api_key = API_KEYS.get(provider)
        if not api_key:
            return jsonify({'error': f'API key for {provider} not configured'}), 500

        # Call AI with tools
        result = xerai_integration.call_ai_with_tools(
            provider=provider,
            message=message,
            api_key=api_key,
            model=MODEL_CONFIGS.get(provider, {}).get('default_model')
        )

        # Track usage
        track_api_usage(
            session['user_id'],
            f'xerai/{provider}',
            model=provider,
            tokens=len(message.split()) * 2  # Rough estimate
        )

        return jsonify(result)

    except Exception as e:
        app.logger.error(f"XerAI chat error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/xerai/create-file', methods=['POST'])
@login_required
@limiter.limit("30 per minute")
@monitor_request
def xerai_create_file():
    """
    Direct file creation endpoint
    """
    try:
        data = request.json
        file_path = data.get('file_path', '')
        content = data.get('content', '')

        if not file_path or not content:
            return jsonify({'error': 'file_path and content are required'}), 400

        result = xerai_integration.file_agent.create_file(file_path, content)

        if result.success:
            # Track usage
            track_api_usage(session['user_id'], 'xerai/create-file')

        return jsonify({
            'success': result.success,
            'message': result.message,
            'error': result.error,
            'data': result.data
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/xerai/files', methods=['GET'])
@login_required
@monitor_request
def xerai_list_files():
    """
    List files in project
    """
    try:
        directory = request.args.get('directory', '.')
        recursive = request.args.get('recursive', 'false').lower() == 'true'

        result = xerai_integration.file_agent.list_files(directory, recursive)

        return jsonify({
            'success': result.success,
            'message': result.message,
            'error': result.error,
            'data': result.data
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/xerai/project-status', methods=['GET'])
@login_required
@monitor_request
def xerai_project_status():
    """
    Get current project status
    """
    try:
        status = xerai_integration.get_project_status()

        return jsonify(status)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/xerai/confirm/<operation_id>', methods=['POST'])
@login_required
@monitor_request
def xerai_confirm_operation(operation_id):
    """
    Confirm a pending file operation
    """
    try:
        data = request.json
        confirmed = data.get('confirmed', False)

        result = xerai_integration.confirm_pending_operation(operation_id, confirmed)

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/xerai/template/<template_name>', methods=['POST'])
@login_required
@limiter.limit("10 per minute")
@monitor_request
def xerai_create_template(template_name):
    """
    Create a project from template
    """
    try:
        data = request.json
        project_name = data.get('project_name', f'new_{template_name}_project')

        result = xerai_integration.create_project_template(template_name, project_name)

        # Track usage
        track_api_usage(session['user_id'], f'xerai/template/{template_name}')

        return jsonify(result)

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/xerai', methods=['GET'])
def xerai_ui():
    """Serve the XerAI Code UI"""
    return send_file('web_ui_integration.html')

# Prometheus metrics endpoint
@app.route('/metrics', methods=['GET'])
def metrics():
    """Prometheus metrics endpoint"""
    return prometheus_client.generate_latest(), 200, {'Content-Type': 'text/plain; charset=utf-8'}

# Background task to update memory usage
def update_memory_metrics():
    """Update memory usage metrics"""
    import psutil
    import threading

    def _update():
        while True:
            memory = psutil.virtual_memory()
            MEMORY_USAGE.set(memory.used)
            time.sleep(60)  # Update every minute

    thread = threading.Thread(target=_update, daemon=True)
    thread.start()

if __name__ == '__main__':
    # Start background metrics updater
    update_memory_metrics()

    # Start Prometheus metrics server in background (with error handling)
    try:
        from prometheus_client import start_http_server
        start_http_server(app.config['PROMETHEUS_PORT'])
        print(f"📊 Metrics server started on port {app.config['PROMETHEUS_PORT']}")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"⚠️  Metrics server port {app.config['PROMETHEUS_PORT']} already in use, skipping metrics server")
        else:
            print(f"⚠️  Failed to start metrics server: {e}")
    except Exception as e:
        print(f"⚠️  Failed to start metrics server: {e}")

    print("="*80)
    print("🚀 SUPER-AI ORCHESTRATOR SERVER - ANDROID EDITION")
    print("="*80)
    print("📡 Server running on http://localhost:5000")
    print(f"📊 Metrics server on http://localhost:{app.config['PROMETHEUS_PORT']}/metrics")
    print("\n🎯 Main Interfaces:")
    print("  GET  /                    - Main UI")
    print("  GET  /orchestrator        - AI Orchestrator UI")
    print("  GET  /android             - Android Dev UI")
    print("  GET  /vscode              - VS Code AI Builder (Claude 4.5 Enhanced) ⭐ NEW!")
    print("\n🔐 Authentication:")
    print("  POST /api/auth/register   - User registration")
    print("  POST /api/auth/login      - User login")
    print("  POST /api/auth/logout     - User logout")
    print("  GET  /api/auth/me         - Current user info")
    print("\n🤖 Individual AI Endpoints:")
    print("  POST /api/groq/chat       - Groq (Fast inference)")
    print("  POST /api/mistral/chat    - Mistral (Ethics & NLG)")
    print("  POST /api/cohere/chat     - Cohere (Coherence)")
    print("  POST /api/gemini/chat     - Gemini (Multimodal)")
    print("  POST /api/kimi/chat       - Kimi K2 (Advanced reasoning)")
    print("  POST /api/huggingface/chat- HuggingFace (Specialized)")
    print("\n⚡ Advanced Features:")
    print("  POST /api/orchestrate     - Super-AI Orchestration")
    print("  POST /api/multi-ai        - Multi-AI Consensus")
    print("  POST /api/execute-code    - Code Execution & Auto-fix")
    print("  POST /api/create-file     - File Creation")
    print("  GET  /health              - Health Check")
    print("  GET  /metrics             - Prometheus Metrics")
    print("\n🤖 Android Development:")
    print("  POST /api/android/autonomous    - Autonomous coding mode")
    print("  POST /api/android/build         - Gradle build")
    print("  POST /api/android/generate-code - AI code generation")
    print("  GET  /api/android/ui-state      - Get UI state")
    print("\n🚀 Enhanced Code Generation (NEW!):")
    print("  POST /api/enhanced/generate     - Multi-file generation (1000-2000+ LOC)")
    print("                                    • Auto error fixing")
    print("                                    • Multi-AI consensus")
    print("                                    • Optimized for maximum LOC")
    print("\n🤖 XerAI Code Auto File Creation (NEW!):")
    print("  POST /api/xerai/chat            - AI chat with auto file creation")
    print("  POST /api/xerai/create-file     - Direct file creation")
    print("  GET  /api/xerai/files           - List project files")
    print("  GET  /api/xerai/project-status  - Get project status")
    print("  POST /api/xerai/confirm/<id>    - Confirm pending operations")
    print("  POST /api/xerai/template/<name> - Create from template")
    print("  GET  /xerai                     - XerAI Code UI ⭐")
    print("\n👑 Admin Panel:")
    print("  GET  /api/admin/users           - User management")
    print("  GET  /api/admin/analytics       - System analytics")
    print("  GET  /api/admin/system-info     - System information")
    print("\n✨ Features:")
    print("  • User authentication & authorization")
    print("  • Rate limiting & request monitoring")
    print("  • Prometheus metrics & logging")
    print("  • SQLite database with full schema")
    print("  • Combines 5 AI models for superior responses")
    print("  • Automatic error detection & correction")
    print("  • Autonomous code generation & file creation")
    print("  • Gradle build integration")
    print("  • VS Code-like UI with sidebar, editor, terminal")
    print("  • Real-time audio processing support")
    print("  • Context-aware Android development")
    print("  • MCP-compatible knowledge storage")
    print("\n🌐 Open your browser to:")
    print("  http://localhost:5000/vscode       (VS Code AI Builder - RECOMMENDED) ⭐")
    print("  http://localhost:5000/android      (Android Dev)")
    print("  http://localhost:5000/orchestrator (AI Orchestrator)")
    print("  http://localhost:5000              (Classic UI)")
    print("="*80)
    print("\n✅ Server ready! Waiting for requests...\n")

    socketio.run(app, debug=True, host='0.0.0.0', port=5000, allow_unsafe_werkzeug=True)