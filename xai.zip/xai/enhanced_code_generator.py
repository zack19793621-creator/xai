"""
Enhanced Code Generator with Automatic Error Fixing
Optimized for maximum LOC output and multi-file generation
"""

import asyncio
import json
import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import ast
import subprocess
import tempfile
import os


class ModelCapability(Enum):
    """Model capabilities for code generation"""
    MULTI_AI = "multi_ai"  # 1000-2000+ LOC
    MISTRAL = "mistral"    # 500-1500 LOC
    GEMINI = "gemini"      # 300-800 LOC
    GROQ = "groq"          # 100-400 LOC
    HUGGINGFACE = "huggingface"  # 100-300 LOC
    COHERE = "cohere"      # 50-200 LOC


@dataclass
class CodeGenerationConfig:
    """Configuration for code generation"""
    target_loc: int
    num_files: int
    language: str
    framework: str
    complexity: str
    auto_fix_errors: bool = True
    max_fix_iterations: int = 5
    enable_validation: bool = True


@dataclass
class GeneratedFile:
    """Represents a generated code file"""
    path: str
    content: str
    language: str
    loc: int
    has_errors: bool = False
    errors: List[str] = None
    fixed_content: Optional[str] = None
    validation_passed: bool = False


@dataclass
class ErrorFix:
    """Represents an error fix"""
    original_error: str
    fix_description: str
    fixed_code: str
    iteration: int


class EnhancedCodeGenerator:
    """
    Advanced code generator with automatic error fixing
    Optimized for maximum LOC and multi-file generation
    """
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        
        # Model capabilities and LOC ranges
        self.model_capabilities = {
            ModelCapability.MULTI_AI: {
                'min_loc': 1000,
                'max_loc': 2000,
                'strength': 'comprehensive_projects',
                'weight': 1.0,
                'best_for': ['full_apps', 'frameworks', 'complex_systems']
            },
            ModelCapability.MISTRAL: {
                'min_loc': 500,
                'max_loc': 1500,
                'strength': 'architecture_expansion',
                'weight': 0.9,
                'best_for': ['scalable_code', 'best_practices', 'structured_design']
            },
            ModelCapability.GEMINI: {
                'min_loc': 300,
                'max_loc': 800,
                'strength': 'quality_accuracy',
                'weight': 0.95,
                'best_for': ['clean_code', 'maintainable', 'logical_structure']
            },
            ModelCapability.GROQ: {
                'min_loc': 100,
                'max_loc': 400,
                'strength': 'speed_efficiency',
                'weight': 0.85,
                'best_for': ['rapid_prototyping', 'quick_fixes', 'small_snippets']
            },
            ModelCapability.HUGGINGFACE: {
                'min_loc': 100,
                'max_loc': 300,
                'strength': 'targeted_generation',
                'weight': 0.8,
                'best_for': ['specific_tasks', 'model_dependent']
            },
            ModelCapability.COHERE: {
                'min_loc': 50,
                'max_loc': 200,
                'strength': 'nlp_refactoring',
                'weight': 0.75,
                'best_for': ['documentation', 'refactoring', 'enhancements']
            }
        }
    
    def select_optimal_models(self, config: CodeGenerationConfig) -> List[ModelCapability]:
        """
        Select optimal AI models based on target LOC and requirements
        """
        target_loc = config.target_loc
        num_files = config.num_files
        
        # For large projects (1000+ LOC), prioritize Multi-AI and Mistral
        if target_loc >= 1000:
            return [
                ModelCapability.MULTI_AI,
                ModelCapability.MISTRAL,
                ModelCapability.GEMINI
            ]
        
        # For medium projects (500-1000 LOC), use Mistral and Gemini
        elif target_loc >= 500:
            return [
                ModelCapability.MISTRAL,
                ModelCapability.GEMINI,
                ModelCapability.GROQ
            ]
        
        # For small projects (< 500 LOC), use Gemini and Groq
        else:
            return [
                ModelCapability.GEMINI,
                ModelCapability.GROQ,
                ModelCapability.COHERE
            ]
    
    async def generate_comprehensive_prompt(
        self,
        config: CodeGenerationConfig,
        file_index: int,
        total_files: int
    ) -> str:
        """
        Generate comprehensive prompt optimized for maximum LOC output
        """
        loc_per_file = config.target_loc // config.num_files
        
        prompt = f"""
Generate a COMPLETE, PRODUCTION-READY {config.language} file for a {config.framework} project.

PROJECT REQUIREMENTS:
- Language: {config.language}
- Framework: {config.framework}
- Complexity: {config.complexity}
- Target LOC: {loc_per_file}+ lines (MINIMUM)
- File {file_index + 1} of {total_files}

CRITICAL REQUIREMENTS FOR MAXIMUM CODE LENGTH:
1. Generate COMPLETE implementations, not stubs or placeholders
2. Include ALL necessary imports and dependencies
3. Add comprehensive error handling for EVERY function
4. Include detailed docstrings and comments (but not excessive)
5. Implement ALL helper functions and utilities
6. Add input validation for ALL parameters
7. Include logging and debugging code
8. Add configuration management
9. Implement proper class hierarchies with inheritance
10. Include unit test helpers and validation methods

CODE STRUCTURE REQUIREMENTS:
- Use descriptive variable and function names
- Implement proper separation of concerns
- Add type hints for all functions (Python) or proper typing (TypeScript/Java)
- Include constants and configuration at the top
- Implement proper exception classes
- Add utility functions for common operations
- Include data validation and sanitization
- Implement caching mechanisms where appropriate
- Add performance optimization code
- Include security best practices

EXPANSION TECHNIQUES TO MAXIMIZE LOC:
1. Break down complex functions into smaller, well-documented functions
2. Add comprehensive input validation with specific error messages
3. Implement builder patterns for complex object creation
4. Add factory methods for object instantiation
5. Include adapter patterns for external integrations
6. Implement strategy patterns for algorithm selection
7. Add observer patterns for event handling
8. Include decorator patterns for functionality extension
9. Implement proper resource management (context managers, try-finally)
10. Add comprehensive logging at all levels (debug, info, warning, error)

SPECIFIC IMPLEMENTATIONS TO INCLUDE:
- Configuration management class
- Logger setup and configuration
- Error handling middleware
- Data validation utilities
- Caching layer implementation
- Retry logic with exponential backoff
- Rate limiting implementation
- Connection pooling
- Health check endpoints
- Metrics collection
- Performance monitoring
- Security utilities (input sanitization, authentication helpers)

DO NOT:
- Use placeholder comments like "# TODO" or "# Implementation here"
- Leave functions empty or with just 'pass'
- Skip error handling
- Omit type hints or documentation
- Use single-letter variable names (except in loops)

GENERATE THE COMPLETE, WORKING CODE NOW:
"""
        
        return prompt
    
    async def generate_code_with_model(
        self,
        model: ModelCapability,
        prompt: str,
        config: CodeGenerationConfig
    ) -> Dict[str, Any]:
        """
        Generate code using specific AI model
        """
        import requests
        
        try:
            if model == ModelCapability.MULTI_AI:
                endpoint = f"{self.base_url}/api/multi-ai"
                response = requests.post(
                    endpoint,
                    json={'prompt': prompt},
                    timeout=120
                )
            elif model == ModelCapability.MISTRAL:
                endpoint = f"{self.base_url}/api/mistral/chat"
                response = requests.post(
                    endpoint,
                    json={
                        'messages': [
                            {'role': 'system', 'content': 'You are an expert code architect specializing in scalable, production-ready code. Generate comprehensive implementations with maximum code length.'},
                            {'role': 'user', 'content': prompt}
                        ],
                        'temperature': 0.3,
                        'max_tokens': 8000
                    },
                    timeout=120
                )
            elif model == ModelCapability.GEMINI:
                endpoint = f"{self.base_url}/api/gemini/chat"
                response = requests.post(
                    endpoint,
                    json={'message': prompt},
                    timeout=120
                )
            elif model == ModelCapability.GROQ:
                endpoint = f"{self.base_url}/api/groq/chat"
                response = requests.post(
                    endpoint,
                    json={
                        'messages': [
                            {'role': 'system', 'content': 'You are a fast, efficient code generator. Generate complete, working code quickly.'},
                            {'role': 'user', 'content': prompt}
                        ],
                        'temperature': 0.2,
                        'max_tokens': 4000
                    },
                    timeout=60
                )
            elif model == ModelCapability.COHERE:
                endpoint = f"{self.base_url}/api/cohere/chat"
                response = requests.post(
                    endpoint,
                    json={'message': prompt},
                    timeout=90
                )
            else:  # HUGGINGFACE
                endpoint = f"{self.base_url}/api/huggingface/chat"
                response = requests.post(
                    endpoint,
                    json={'message': prompt},
                    timeout=90
                )
            
            if response.status_code == 200:
                data = response.json()
                
                # Extract text based on response format
                if 'results' in data:  # Multi-AI
                    text = '\n\n'.join([r['response'] for r in data['results']])
                elif 'choices' in data:  # Groq, Mistral
                    text = data['choices'][0]['message']['content']
                elif 'text' in data:  # Gemini, Cohere, HuggingFace
                    text = data['text']
                else:
                    text = str(data)
                
                return {
                    'success': True,
                    'text': text,
                    'model': model.value,
                    'loc': len(text.split('\n'))
                }
            else:
                return {
                    'success': False,
                    'error': f"HTTP {response.status_code}",
                    'model': model.value
                }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'model': model.value
            }
    
    def extract_code_from_response(self, text: str, language: str) -> str:
        """
        Extract code from AI response, removing markdown and explanations
        """
        # Try to extract code blocks
        code_block_pattern = rf'```{language}?\n(.*?)```'
        matches = re.findall(code_block_pattern, text, re.DOTALL)
        
        if matches:
            # Combine all code blocks
            return '\n\n'.join(matches)
        
        # If no code blocks, try to extract code-like content
        lines = text.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            # Skip obvious explanation lines
            if line.strip().startswith(('Here', 'This', 'The', 'I', 'Let', 'Note:')):
                continue
            
            # Detect code patterns
            if any(pattern in line for pattern in ['def ', 'class ', 'import ', 'from ', 'function ', 'const ', 'let ', 'var ', 'public ', 'private ']):
                in_code = True
            
            if in_code:
                code_lines.append(line)
        
        return '\n'.join(code_lines) if code_lines else text
    
    def count_loc(self, code: str) -> int:
        """
        Count lines of code (excluding empty lines and comments)
        """
        lines = code.split('\n')
        loc = 0
        
        for line in lines:
            stripped = line.strip()
            # Count non-empty, non-comment lines
            if stripped and not stripped.startswith(('#', '//', '/*', '*', '*/')):
                loc += 1
        
        return loc
    
    async def validate_code(
        self,
        code: str,
        language: str
    ) -> Tuple[bool, List[str]]:
        """
        Validate code for syntax errors
        """
        errors = []
        
        try:
            if language.lower() == 'python':
                # Python syntax validation
                try:
                    ast.parse(code)
                    return True, []
                except SyntaxError as e:
                    errors.append(f"Syntax error at line {e.lineno}: {e.msg}")
                    return False, errors
            
            elif language.lower() in ['javascript', 'typescript']:
                # JavaScript/TypeScript validation using Node.js
                with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
                    f.write(code)
                    temp_file = f.name
                
                try:
                    result = subprocess.run(
                        ['node', '--check', temp_file],
                        capture_output=True,
                        text=True,
                        timeout=5
                    )
                    
                    if result.returncode != 0:
                        errors.append(result.stderr)
                        return False, errors
                    
                    return True, []
                finally:
                    os.unlink(temp_file)
            
            elif language.lower() in ['java', 'kotlin']:
                # Basic validation for Java/Kotlin
                # Check for basic syntax patterns
                if not any(keyword in code for keyword in ['class ', 'interface ', 'fun ', 'public ']):
                    errors.append("No class or function definitions found")
                    return False, errors
                
                return True, []
            
            else:
                # For other languages, do basic checks
                if len(code.strip()) < 10:
                    errors.append("Code too short")
                    return False, errors
                
                return True, []
        
        except Exception as e:
            errors.append(f"Validation error: {str(e)}")
            return False, errors
    
    async def auto_fix_errors(
        self,
        code: str,
        errors: List[str],
        language: str,
        iteration: int = 0
    ) -> ErrorFix:
        """
        Automatically fix code errors using AI
        """
        fix_prompt = f"""
FIX THE FOLLOWING {language.upper()} CODE ERRORS:

ERRORS:
{chr(10).join([f"- {error}" for error in errors])}

ORIGINAL CODE:
```{language}
{code}
```

REQUIREMENTS:
1. Fix ALL errors listed above
2. Maintain the original functionality
3. Keep the same code structure
4. Do NOT reduce the code length
5. Add error handling if missing
6. Ensure proper syntax
7. Add type hints if missing (Python)
8. Fix indentation issues
9. Add missing imports
10. Fix variable naming conflicts

PROVIDE THE COMPLETE FIXED CODE (not just the changes):
"""
        
        # Use multiple models for error fixing
        models = [ModelCapability.GEMINI, ModelCapability.MISTRAL]
        
        for model in models:
            result = await self.generate_code_with_model(
                model,
                fix_prompt,
                CodeGenerationConfig(
                    target_loc=len(code.split('\n')),
                    num_files=1,
                    language=language,
                    framework='',
                    complexity='high'
                )
            )
            
            if result['success']:
                fixed_code = self.extract_code_from_response(result['text'], language)
                
                # Validate fixed code
                is_valid, new_errors = await self.validate_code(fixed_code, language)
                
                if is_valid or len(new_errors) < len(errors):
                    return ErrorFix(
                        original_error='; '.join(errors),
                        fix_description=f"Fixed by {model.value}",
                        fixed_code=fixed_code,
                        iteration=iteration
                    )
        
        # If all models fail, return original with description
        return ErrorFix(
            original_error='; '.join(errors),
            fix_description="Could not auto-fix, manual review needed",
            fixed_code=code,
            iteration=iteration
        )
    
    async def generate_multi_file_project(
        self,
        config: CodeGenerationConfig,
        project_description: str
    ) -> List[GeneratedFile]:
        """
        Generate complete multi-file project with automatic error fixing
        """
        print(f"\n{'='*80}")
        print(f"🚀 ENHANCED CODE GENERATOR")
        print(f"{'='*80}")
        print(f"Target LOC: {config.target_loc}")
        print(f"Number of Files: {config.num_files}")
        print(f"Language: {config.language}")
        print(f"Framework: {config.framework}")
        print(f"Auto-fix Errors: {config.auto_fix_errors}")
        print(f"{'='*80}\n")
        
        # Select optimal models
        models = self.select_optimal_models(config)
        print(f"📊 Selected Models: {[m.value for m in models]}")
        
        # Calculate LOC per file
        loc_per_file = config.target_loc // config.num_files
        print(f"📏 Target LOC per file: {loc_per_file}\n")
        
        generated_files = []
        
        # Generate each file
        for i in range(config.num_files):
            print(f"\n{'─'*80}")
            print(f"📄 Generating File {i+1}/{config.num_files}")
            print(f"{'─'*80}")
            
            # Generate comprehensive prompt
            prompt = await self.generate_comprehensive_prompt(config, i, config.num_files)
            prompt = f"{project_description}\n\n{prompt}"
            
            # Try each model until we get sufficient LOC
            best_result = None
            best_loc = 0
            
            for model in models:
                print(f"  🤖 Trying {model.value}...")
                
                result = await self.generate_code_with_model(model, prompt, config)
                
                if result['success']:
                    code = self.extract_code_from_response(result['text'], config.language)
                    loc = self.count_loc(code)
                    
                    print(f"     ✅ Generated {loc} LOC")
                    
                    if loc > best_loc:
                        best_result = code
                        best_loc = loc
                    
                    # If we hit target, break
                    if loc >= loc_per_file:
                        break
                else:
                    print(f"     ❌ Failed: {result.get('error')}")
            
            if not best_result:
                print(f"  ⚠️  No models succeeded, skipping file")
                continue
            
            # Validate code
            print(f"  🔍 Validating code...")
            is_valid, errors = await self.validate_code(best_result, config.language)
            
            file_obj = GeneratedFile(
                path=f"generated_file_{i+1}.{self._get_extension(config.language)}",
                content=best_result,
                language=config.language,
                loc=best_loc,
                has_errors=not is_valid,
                errors=errors if not is_valid else []
            )
            
            # Auto-fix errors if enabled
            if not is_valid and config.auto_fix_errors:
                print(f"  🔧 Auto-fixing {len(errors)} error(s)...")
                
                current_code = best_result
                iteration = 0
                
                while iteration < config.max_fix_iterations and errors:
                    fix = await self.auto_fix_errors(
                        current_code,
                        errors,
                        config.language,
                        iteration
                    )
                    
                    current_code = fix.fixed_code
                    
                    # Re-validate
                    is_valid, errors = await self.validate_code(current_code, config.language)
                    
                    if is_valid:
                        print(f"     ✅ Fixed in iteration {iteration + 1}")
                        file_obj.fixed_content = current_code
                        file_obj.has_errors = False
                        file_obj.errors = []
                        file_obj.validation_passed = True
                        break
                    
                    iteration += 1
                
                if errors:
                    print(f"     ⚠️  Could not fix all errors after {config.max_fix_iterations} iterations")
            else:
                file_obj.validation_passed = is_valid
            
            generated_files.append(file_obj)
            
            print(f"  📊 Final LOC: {file_obj.loc}")
            print(f"  ✅ Validation: {'PASSED' if file_obj.validation_passed else 'FAILED'}")
        
        # Summary
        total_loc = sum(f.loc for f in generated_files)
        valid_files = sum(1 for f in generated_files if f.validation_passed)
        
        print(f"\n{'='*80}")
        print(f"📊 GENERATION SUMMARY")
        print(f"{'='*80}")
        print(f"Total Files: {len(generated_files)}")
        print(f"Total LOC: {total_loc}")
        print(f"Valid Files: {valid_files}/{len(generated_files)}")
        print(f"Average LOC per file: {total_loc // len(generated_files) if generated_files else 0}")
        print(f"{'='*80}\n")
        
        return generated_files
    
    def _get_extension(self, language: str) -> str:
        """Get file extension for language"""
        extensions = {
            'python': 'py',
            'javascript': 'js',
            'typescript': 'ts',
            'java': 'java',
            'kotlin': 'kt',
            'go': 'go',
            'rust': 'rs',
            'cpp': 'cpp',
            'c': 'c'
        }
        return extensions.get(language.lower(), 'txt')


async def main():
    """Example usage"""
    generator = EnhancedCodeGenerator()
    
    # Example: Generate a complete Flask API with 2000+ LOC
    config = CodeGenerationConfig(
        target_loc=2000,
        num_files=5,
        language='python',
        framework='Flask',
        complexity='high',
        auto_fix_errors=True,
        max_fix_iterations=5
    )
    
    project_description = """
Create a complete REST API for a task management system with:
- User authentication and authorization
- CRUD operations for tasks
- Database integration (SQLAlchemy)
- Error handling and logging
- Input validation
- API documentation
- Unit tests
- Configuration management
"""
    
    files = await generator.generate_multi_file_project(config, project_description)
    
    # Save generated files
    for file in files:
        content = file.fixed_content if file.fixed_content else file.content
        with open(file.path, 'w') as f:
            f.write(content)
        print(f"✅ Saved: {file.path} ({file.loc} LOC)")


if __name__ == "__main__":
    asyncio.run(main())
