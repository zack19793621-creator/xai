"""
Advanced AI Orchestrator - Super-AI System
Integrates Groq, Gemini, Mistral, Hugging Face, and Cohere
to produce unified, high-quality responses that surpass individual AI capabilities.
"""

import requests
import json
import time
from typing import Dict, List, Tuple, Any
from collections import Counter
import re


class AIOrchestrator:
    """
    Advanced AI orchestration system that combines multiple AI models
    to produce superior, error-free, comprehensive responses.
    """
    
    def __init__(self, base_url: str = "http://localhost:5000"):
        self.base_url = base_url
        self.ai_endpoints = {
            'groq': '/api/groq/chat',
            'gemini': '/api/gemini/chat',
            'mistral': '/api/mistral/chat',
            'huggingface': '/api/huggingface/chat',
            'cohere': '/api/cohere/chat'
        }
        
        # AI strengths and weights for consensus building
        self.ai_strengths = {
            'groq': {
                'speed': 1.0,
                'real_time': 1.0,
                'inference': 0.9,
                'weight': 0.85
            },
            'gemini': {
                'multimodal': 1.0,
                'context': 1.0,
                'reasoning': 0.95,
                'depth': 1.0,
                'weight': 1.0
            },
            'mistral': {
                'nlg': 1.0,
                'ethics': 1.0,
                'alignment': 0.95,
                'weight': 0.9
            },
            'huggingface': {
                'specialization': 0.9,
                'adaptability': 0.95,
                'open_source': 1.0,
                'weight': 0.8
            },
            'cohere': {
                'coherence': 1.0,
                'text_generation': 0.95,
                'optimization': 0.9,
                'weight': 0.85
            }
        }
    
    def query_ai(self, ai_name: str, prompt: str, context: str = "") -> Dict[str, Any]:
        """Query a specific AI model with error handling."""
        try:
            endpoint = self.base_url + self.ai_endpoints[ai_name]
            
            # Format request based on AI type
            if ai_name in ['groq', 'mistral']:
                payload = {
                    'messages': [
                        {'role': 'system', 'content': context if context else 'You are a helpful AI assistant.'},
                        {'role': 'user', 'content': prompt}
                    ]
                }
            else:  # gemini, huggingface, cohere
                payload = {
                    'message': f"{context}\n\n{prompt}" if context else prompt
                }
            
            response = requests.post(
                endpoint,
                headers={'Content-Type': 'application/json'},
                json=payload,
                timeout=60
            )
            
            if response.status_code == 200:
                result = response.json()
                
                # Extract text based on response format
                if 'choices' in result:
                    text = result['choices'][0]['message']['content']
                elif 'text' in result:
                    text = result['text']
                else:
                    text = str(result)
                
                return {
                    'success': True,
                    'text': text,
                    'ai': ai_name,
                    'weight': self.ai_strengths[ai_name]['weight']
                }
            else:
                return {
                    'success': False,
                    'error': f"HTTP {response.status_code}",
                    'ai': ai_name
                }
        
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'ai': ai_name
            }
    
    def parallel_query_all(self, prompt: str, context: str = "") -> List[Dict[str, Any]]:
        """Query all AI models and collect responses."""
        print(f"\n🔄 Querying all AI models...")
        responses = []
        
        for ai_name in self.ai_endpoints.keys():
            print(f"  ⚡ Querying {ai_name.upper()}...")
            result = self.query_ai(ai_name, prompt, context)
            if result['success']:
                print(f"  ✅ {ai_name.upper()} responded successfully")
                responses.append(result)
            else:
                print(f"  ❌ {ai_name.upper()} failed: {result.get('error', 'Unknown error')}")
        
        return responses
    
    def extract_code_blocks(self, text: str) -> List[Tuple[str, str]]:
        """Extract code blocks from text with language detection."""
        pattern = r'```(\w+)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        return [(lang or 'unknown', code.strip()) for lang, code in matches]
    
    def validate_code(self, code: str, language: str) -> Dict[str, Any]:
        """Validate code using AI consensus."""
        validation_prompt = f"""
Analyze this {language} code for errors, bugs, and improvements:

```{language}
{code}
```

Provide:
1. Syntax errors (if any)
2. Logic errors (if any)
3. Security issues (if any)
4. Performance improvements
5. Best practices violations
6. Corrected version (if needed)

Be concise and specific.
"""
        
        responses = self.parallel_query_all(validation_prompt)
        
        # Check if any AI found errors
        error_count = sum(1 for r in responses if 'error' in r['text'].lower() or 'bug' in r['text'].lower())
        
        return {
            'has_errors': error_count > len(responses) / 2,
            'validations': responses,
            'error_count': error_count
        }
    
    def consensus_builder(self, responses: List[Dict[str, Any]], query_type: str = 'general') -> str:
        """
        Build consensus from multiple AI responses using weighted voting
        and quality metrics.
        """
        if not responses:
            return "Error: No responses received from AI models."
        
        print(f"\n🧠 Building consensus from {len(responses)} AI responses...")
        
        # For coding tasks, prioritize accuracy and validation
        if query_type == 'code':
            return self._consensus_code(responses)
        
        # For general tasks, use weighted synthesis
        return self._consensus_general(responses)
    
    def _consensus_general(self, responses: List[Dict[str, Any]]) -> str:
        """Build consensus for general queries."""
        # Extract key points from each response
        all_text = "\n\n---\n\n".join([
            f"**{r['ai'].upper()} (weight: {r['weight']}):**\n{r['text']}"
            for r in responses
        ])
        
        # Use Gemini (highest weight) to synthesize
        synthesis_prompt = f"""
You are tasked with creating a single, comprehensive, ultra-high-quality response by synthesizing the following outputs from multiple AI models. Each model has contributed its expertise:

{all_text}

Your task:
1. Identify common themes and agreements across all responses
2. Resolve any contradictions by favoring higher-weighted models
3. Combine the best insights from each model
4. Produce ONE cohesive, detailed, error-free response
5. Include step-by-step reasoning where applicable
6. Provide examples and actionable insights
7. Ensure factual accuracy by cross-referencing information
8. Make the response comprehensive yet well-structured

Create the final synthesized response now:
"""
        
        print("  🎯 Synthesizing with Gemini (primary)...")
        synthesis = self.query_ai('gemini', synthesis_prompt)
        
        if synthesis['success']:
            return synthesis['text']
        
        # Fallback to Mistral if Gemini fails
        print("  🔄 Gemini failed, using Mistral fallback...")
        synthesis = self.query_ai('mistral', synthesis_prompt)
        return synthesis['text'] if synthesis['success'] else all_text
    
    def _consensus_code(self, responses: List[Dict[str, Any]]) -> str:
        """Build consensus for code-related queries with validation."""
        # Extract all code blocks from responses
        all_codes = []
        for response in responses:
            codes = self.extract_code_blocks(response['text'])
            all_codes.extend([(response['ai'], lang, code) for lang, code in codes])
        
        if not all_codes:
            # No code blocks, treat as general response
            return self._consensus_general(responses)
        
        # Validate each code block
        print(f"  🔍 Found {len(all_codes)} code blocks, validating...")
        validated_codes = []
        
        for ai, lang, code in all_codes:
            validation = self.validate_code(code, lang)
            validated_codes.append({
                'ai': ai,
                'language': lang,
                'code': code,
                'has_errors': validation['has_errors'],
                'validations': validation['validations']
            })
        
        # Select best code (fewest errors)
        best_code = min(validated_codes, key=lambda x: x['has_errors'])
        
        # If best code still has errors, request correction
        if best_code['has_errors']:
            print("  🔧 Errors detected, requesting correction...")
            correction_prompt = f"""
The following {best_code['language']} code has errors. Fix all issues:

```{best_code['language']}
{best_code['code']}
```

Provide:
1. Corrected, error-free code
2. Explanation of fixes
3. Best practices applied
"""
            correction = self.query_ai('gemini', correction_prompt)
            if correction['success']:
                return correction['text']
        
        # Compile final response with best code and explanations
        final_response = f"""
# Optimized Solution

## Code ({best_code['language']})

```{best_code['language']}
{best_code['code']}
```

## Analysis

"""
        
        # Add insights from all AIs
        for response in responses:
            final_response += f"\n### {response['ai'].upper()} Insights:\n{response['text']}\n"
        
        return final_response
    
    def self_correct(self, response: str, original_query: str, max_iterations: int = 3) -> str:
        """
        Self-correction mechanism: validate response and refine if needed.
        """
        print(f"\n🔍 Self-correction phase (max {max_iterations} iterations)...")
        
        for iteration in range(max_iterations):
            print(f"  📊 Iteration {iteration + 1}/{max_iterations}")
            
            # Ask AIs to critique the response
            critique_prompt = f"""
Analyze this response for errors, inaccuracies, or improvements:

Original Query: {original_query}

Response:
{response}

Provide:
1. Factual errors (if any)
2. Logical inconsistencies (if any)
3. Missing information
4. Suggested improvements
5. Overall quality score (1-10)

Be critical and thorough.
"""
            
            critiques = self.parallel_query_all(critique_prompt)
            
            # Calculate average quality score
            scores = []
            needs_correction = False
            
            for critique in critiques:
                text = critique['text'].lower()
                
                # Check for error indicators
                if any(word in text for word in ['error', 'incorrect', 'wrong', 'inaccurate', 'missing']):
                    needs_correction = True
                
                # Extract score if present
                score_match = re.search(r'score[:\s]+(\d+)', text)
                if score_match:
                    scores.append(int(score_match.group(1)))
            
            avg_score = sum(scores) / len(scores) if scores else 8
            print(f"  📈 Average quality score: {avg_score:.1f}/10")
            
            # If quality is high enough, stop
            if avg_score >= 8.5 and not needs_correction:
                print(f"  ✅ Quality threshold met, stopping corrections")
                break
            
            # Otherwise, refine the response
            if needs_correction:
                print(f"  🔧 Issues detected, refining response...")
                
                refinement_prompt = f"""
Improve this response based on the following critiques:

Original Query: {original_query}

Current Response:
{response}

Critiques:
{chr(10).join([f"- {c['ai'].upper()}: {c['text']}" for c in critiques])}

Provide an improved, error-free version that addresses all issues.
"""
                
                refined = self.query_ai('gemini', refinement_prompt)
                if refined['success']:
                    response = refined['text']
                else:
                    break
        
        return response
    
    def process_query(self, user_query: str, query_type: str = 'general', 
                     enable_self_correction: bool = True) -> str:
        """
        Main orchestration method: process user query through all AIs
        and produce unified, high-quality response.
        
        Args:
            user_query: The user's question or task
            query_type: 'general', 'code', 'analysis', etc.
            enable_self_correction: Whether to apply self-correction
        
        Returns:
            Unified, high-quality response
        """
        print("="*80)
        print("🚀 AI ORCHESTRATOR - SUPER-AI SYSTEM")
        print("="*80)
        print(f"\n📝 Query: {user_query}")
        print(f"🎯 Type: {query_type}")
        print(f"🔧 Self-correction: {'Enabled' if enable_self_correction else 'Disabled'}")
        
        # Step 1: Query all AIs
        start_time = time.time()
        responses = self.parallel_query_all(user_query)
        
        if not responses:
            return "❌ Error: No AI models responded successfully. Please check the server."
        
        print(f"\n✅ Received {len(responses)}/{len(self.ai_endpoints)} responses")
        
        # Step 2: Build consensus
        consensus_response = self.consensus_builder(responses, query_type)
        
        # Step 3: Self-correction (if enabled)
        if enable_self_correction:
            consensus_response = self.self_correct(consensus_response, user_query)
        
        # Step 4: Final quality check
        elapsed_time = time.time() - start_time
        
        print("\n" + "="*80)
        print(f"✨ ORCHESTRATION COMPLETE")
        print(f"⏱️  Total time: {elapsed_time:.2f}s")
        print(f"🤖 Models used: {', '.join([r['ai'].upper() for r in responses])}")
        print("="*80 + "\n")
        
        return consensus_response


def main():
    """Example usage of the AI Orchestrator."""
    orchestrator = AIOrchestrator()
    
    # Example queries
    examples = [
        {
            'query': 'Explain quantum entanglement in simple terms with examples.',
            'type': 'general'
        },
        {
            'query': 'Write a Python function to find the longest palindromic substring in a string. Include error handling and optimize for performance.',
            'type': 'code'
        },
        {
            'query': 'What are the ethical implications of AI in healthcare? Provide a balanced analysis.',
            'type': 'analysis'
        }
    ]
    
    print("\n" + "="*80)
    print("AI ORCHESTRATOR - INTERACTIVE MODE")
    print("="*80)
    print("\nCommands:")
    print("  - Type your query to get a response")
    print("  - Type 'example' to see example queries")
    print("  - Type 'exit' to quit")
    print("="*80 + "\n")
    
    while True:
        user_input = input("\n💬 Your query (or 'exit'): ").strip()
        
        if user_input.lower() == 'exit':
            print("\n👋 Goodbye!")
            break
        
        if user_input.lower() == 'example':
            print("\n📚 Example queries:")
            for i, ex in enumerate(examples, 1):
                print(f"\n{i}. {ex['query']}")
                print(f"   Type: {ex['type']}")
            continue
        
        if not user_input:
            continue
        
        # Detect query type
        query_type = 'code' if any(word in user_input.lower() for word in ['code', 'function', 'program', 'script']) else 'general'
        
        # Process query
        response = orchestrator.process_query(user_input, query_type=query_type)
        
        print("\n" + "="*80)
        print("📤 UNIFIED RESPONSE")
        print("="*80 + "\n")
        print(response)
        print("\n" + "="*80)


if __name__ == "__main__":
    main()
