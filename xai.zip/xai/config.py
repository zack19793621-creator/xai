"""
Advanced configuration for AI Orchestrator
"""

import os
from datetime import timedelta
from typing import List, Dict, Any
import secrets

class Config:
    """Base configuration"""

    # Flask
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(32))
    FLASK_ENV = os.environ.get('FLASK_ENV', 'development')
    FLASK_DEBUG = os.environ.get('FLASK_DEBUG', 'True').lower() == 'true'

    # Database
    DATABASE_PATH = os.path.join(os.path.dirname(__file__), 'ai_orchestrator.db')
    SQLALCHEMY_DATABASE_URI = f'sqlite:///{DATABASE_PATH}'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # JWT
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', secrets.token_hex(32))
    JWT_ACCESS_TOKEN_EXPIRE = timedelta(hours=1)
    JWT_REFRESH_TOKEN_EXPIRE = timedelta(days=30)

    # Session
    SESSION_TYPE = os.environ.get('SESSION_TYPE', 'filesystem')
    SESSION_PERMANENT = os.environ.get('SESSION_PERMANENT', 'False').lower() == 'true'
    SESSION_USE_SIGNER = os.environ.get('SESSION_USE_SIGNER', 'True').lower() == 'true'
    SESSION_KEY_PREFIX = 'ai_orchestrator:'
    SESSION_FILE_DIR = os.path.join(os.path.dirname(__file__), 'sessions')

    # Rate limiting
    RATELIMIT_STORAGE_URL = os.environ.get('RATELIMIT_STORAGE_URL', "memory://")
    RATELIMIT_STRATEGY = os.environ.get('RATELIMIT_STRATEGY', "fixed-window")
    RATELIMIT_DEFAULT = os.environ.get('RATELIMIT_DEFAULT', "100 per minute")

    # CORS
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', 'http://localhost:5000,http://127.0.0.1:5000').split(',')

    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FILE = os.path.join(os.path.dirname(__file__), 'logs', 'ai_orchestrator.log')
    LOG_MAX_BYTES = 10 * 1024 * 1024  # 10MB
    LOG_BACKUP_COUNT = 5

    # Monitoring
    PROMETHEUS_PORT = int(os.environ.get('PROMETHEUS_PORT', 8000))
    METRICS_UPDATE_INTERVAL = 60  # seconds

    # AI Models Configuration
    AI_MODELS = {
        'groq': {
            'api_key': os.environ.get('GROQ_API_KEY', ''),
            'endpoint': 'https://api.groq.com/openai/v1/chat/completions',
            'models': ['gemma2-9b-it', 'llama2-70b-4096'],
            'rate_limit': '100 per minute',
            'timeout': 30
        },
        'mistral': {
            'api_key': os.environ.get('MISTRAL_API_KEY', ''),
            'endpoint': 'https://api.mistral.ai/v1/chat/completions',
            'models': ['mistral-small-latest', 'mistral-medium-latest'],
            'rate_limit': '50 per minute',
            'timeout': 30
        },
        'cohere': {
            'api_key': os.environ.get('COHERE_API_KEY', ''),
            'endpoint': 'https://api.cohere.ai/v1/chat',
            'models': ['command-a-03-2025', 'command-r-plus'],
            'rate_limit': '100 per minute',
            'timeout': 30
        },
        'gemini': {
            'api_key': os.environ.get('GEMINI_API_KEY', ''),
            'endpoint': 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent',
            'models': ['gemini-1.5-pro', 'gemini-1.5-flash'],
            'rate_limit': '60 per minute',
            'timeout': 45
        },
        'huggingface': {
            'api_key': os.environ.get('HUGGINGFACE_API_KEY', ''),
            'endpoint': 'https://api-inference.huggingface.co/models/microsoft/DialoGPT-small',
            'models': ['microsoft/DialoGPT-small', 'microsoft/DialoGPT-medium'],
            'rate_limit': '30 per minute',
            'timeout': 45
        }
    }

    # Android Development
    ANDROID_HOME = os.environ.get('ANDROID_HOME', '/opt/android-sdk')
    GRADLE_BUILD_TIMEOUT = 300  # 5 minutes
    APK_OUTPUT_DIR = 'app/build/outputs/apk'

    # Code Generation
    MAX_CODE_GENERATION_LOC = 5000
    CODE_GENERATION_TIMEOUT = 120  # seconds
    AUTO_FIX_ITERATIONS = 5

    # File Upload
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    ALLOWED_EXTENSIONS = {'.py', '.java', '.kt', '.xml', '.json', '.md', '.txt'}

    # Cache
    CACHE_TYPE = 'simple'
    CACHE_DEFAULT_TIMEOUT = 300

    # Security
    BCRYPT_ROUNDS = 12
    PASSWORD_MIN_LENGTH = 8
    PASSWORD_MAX_LENGTH = 128

    # Backup
    BACKUP_ENABLED = True
    BACKUP_INTERVAL = 86400  # 24 hours
    BACKUP_RETENTION = 7  # days

class DevelopmentConfig(Config):
    """Development configuration"""
    FLASK_DEBUG = True
    LOG_LEVEL = 'DEBUG'

class ProductionConfig(Config):
    """Production configuration"""
    FLASK_DEBUG = False
    LOG_LEVEL = 'WARNING'

    # Use more secure settings in production
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SECURE = True
    REMEMBER_COOKIE_HTTPONLY = True

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    FLASK_DEBUG = True
    DATABASE_PATH = os.path.join(os.path.dirname(__file__), 'test.db')
    SQLALCHEMY_DATABASE_URI = f'sqlite:///{DATABASE_PATH}'
    WTF_CSRF_ENABLED = False

# Configuration mapping
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config(config_name: str = None) -> Config:
    """Get configuration instance"""
    if config_name is None:
        config_name = os.environ.get('FLASK_ENV', 'development')

    return config.get(config_name, config['default'])()