"""
Flask server for XerAI Code Web Interface
Connects the web UI to the unified AI system
"""

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import asyncio
from ai_agent_integration import XerAICodeIntegration
import os
import json
from pathlib import Path

app = Flask(__name__)
CORS(app)  # Enable CORS for web interface

# Initialize AI agent
PROJECT_ROOT = os.getenv('PROJECT_ROOT', os.getcwd())
xerai_integration = XerAICodeIntegration(
    project_root=PROJECT_ROOT,
    api_base_url="http://localhost:5000",
    safe_mode=True
)

@app.route('/')
def index():
    """Serve the web interface"""
    return send_from_directory('.', 'web_ui_integration.html')

@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Handle chat requests from web interface

    Request body:
    {
        "message": "user message",
        "auto_create": true/false,
        "use_multiple": true/false
    }
    """
    try:
        data = request.json
        message = data.get('message', '')
        auto_create = data.get('auto_create', True)
        use_multiple = data.get('use_multiple', False)

        if not message:
            return jsonify({'error': 'Message is required'}), 400

        # For now, use Groq as the primary provider
        provider = 'groq'
        api_key = os.environ.get('GROQ_API_KEY', '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')

        # Get AI response with tools
        result = xerai_integration.call_ai_with_tools(
            provider=provider,
            message=message,
            api_key=api_key,
            model='gemma2-9b-it'
        )

        # Get files created in this interaction
        recent_changes = xerai_integration.file_agent.get_change_history()[-10:]  # Last 10 changes
        files_created = [
            {
                'path': change['file_path'],
                'action': change['action'],
                'timestamp': change['timestamp']
            }
            for change in recent_changes
        ]

        return jsonify({
            'success': True,
            'response': result.get('response', ''),
            'files_created': files_created,
            'tool_results': result.get('tool_results', []),
            'providers_used': 1
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/files', methods=['GET'])
def list_files():
    """List all files in the project"""
    try:
        directory = request.args.get('directory', '.')
        recursive = request.args.get('recursive', 'false').lower() == 'true'

        result = xerai_integration.file_agent.list_files(directory, recursive)

        if result.success:
            return jsonify({
                'success': True,
                'files': result.data.get('files', [])
            })
        else:
            return jsonify({
                'success': False,
                'error': result.error
            }), 500

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/file/<path:filepath>', methods=['GET'])
def read_file(filepath):
    """Read a specific file"""
    try:
        result = xerai_integration.file_agent.read_file(filepath)

        if result.success:
            return jsonify({
                'success': True,
                'content': result.data.get('content', ''),
                'size': result.data.get('size', 0)
            })
        else:
            return jsonify({
                'success': False,
                'error': result.error
            }), 404

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/file', methods=['POST'])
def create_file():
    """Create a file manually"""
    try:
        data = request.json
        filepath = data.get('filepath')
        content = data.get('content')

        if not filepath or content is None:
            return jsonify({'error': 'filepath and content are required'}), 400

        result = xerai_integration.file_agent.create_file(filepath, content)

        return jsonify({
            'success': result.success,
            'message': result.message,
            'error': result.error,
            'data': result.data
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/file', methods=['PUT'])
def edit_file():
    """Edit a file manually"""
    try:
        data = request.json
        filepath = data.get('filepath')
        content = data.get('content')

        if not filepath or content is None:
            return jsonify({'error': 'filepath and content are required'}), 400

        result = xerai_integration.file_agent.edit_file(filepath, content)

        return jsonify({
            'success': result.success,
            'message': result.message,
            'error': result.error,
            'data': result.data
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/file/<path:filepath>', methods=['DELETE'])
def delete_file(filepath):
    """Delete a file"""
    try:
        result = xerai_integration.file_agent.delete_file(filepath)
        return jsonify({
            'success': result.success,
            'message': result.message,
            'error': result.error,
            'data': result.data
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get conversation history"""
    try:
        return jsonify({
            'success': True,
            'history': xerai_integration.conversation_history
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/history', methods=['DELETE'])
def clear_history():
    """Clear conversation history"""
    try:
        xerai_integration.conversation_history = []
        return jsonify({
            'success': True,
            'message': 'History cleared'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/changes', methods=['GET'])
def get_changes():
    """Get file change history"""
    try:
        return jsonify({
            'success': True,
            'changes': xerai_integration.file_agent.get_change_history()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get system status"""
    try:
        status = xerai_integration.get_project_status()
        return jsonify({
            'success': True,
            'status': {
                'project_root': PROJECT_ROOT,
                'safe_mode': xerai_integration.file_agent.safe_mode,
                'conversation_length': len(xerai_integration.conversation_history),
                'files_created': len(xerai_integration.file_agent.get_change_history()),
                'providers': ['groq', 'mistral', 'cohere', 'gemini', 'kimi']
            }
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/config', methods=['POST'])
def update_config():
    """Update configuration"""
    try:
        data = request.json

        if 'safe_mode' in data:
            xerai_integration.file_agent.safe_mode = data['safe_mode']

        if 'project_root' in data:
            xerai_integration.project_root = data['project_root']
            xerai_integration.file_agent.project_root = Path(data['project_root'])

        return jsonify({
            'success': True,
            'message': 'Configuration updated'
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/template/<template_name>', methods=['POST'])
def create_template(template_name):
    """Create a project from template"""
    try:
        data = request.json
        project_name = data.get('project_name', f'new_{template_name}_project')

        result = xerai_integration.create_project_template(template_name, project_name)

        return jsonify({
            'success': result.get('success', False),
            'message': f"Template '{template_name}' created as '{project_name}'",
            'files_created': result.get('files_created', []),
            'errors': result.get('errors', [])
        })

    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("=" * 60)
    print("🚀 XerAI Code Server Starting...")
    print("=" * 60)
    print(f"📁 Project Root: {PROJECT_ROOT}")
    print(f"🔒 Safe Mode: {xerai_integration.file_agent.safe_mode}")
    print(f"🤖 AI Providers: groq, mistral, cohere, gemini, kimi")
    print(f"🌐 Server: http://localhost:5000")
    print("=" * 60)
    print("\nEndpoints:")
    print("  POST   /api/chat          - Send message to AI")
    print("  GET    /api/files         - List all files")
    print("  GET    /api/file/<path>   - Read file")
    print("  POST   /api/file          - Create file")
    print("  PUT    /api/file          - Edit file")
    print("  DELETE /api/file/<path>   - Delete file")
    print("  GET    /api/history       - Get conversation")
    print("  DELETE /api/history       - Clear conversation")
    print("  GET    /api/changes       - Get file changes")
    print("  GET    /api/status        - Get system status")
    print("  POST   /api/config        - Update configuration")
    print("  POST   /api/template/<name> - Create from template")
    print("=" * 60)

    app.run(
        host='0.0.0.0',
        port=5001,
        debug=True
    )