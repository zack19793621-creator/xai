"""
Unit tests for task management functionality
"""

import pytest
import json
from datetime import datetime, timedelta
from server import app, get_db
from models.task import Task
from models.user import User


class TestTaskModel:
    """Test Task model functions"""

    def setup_method(self):
        """Setup test database"""
        with app.app_context():
            db = get_db()
            # Clear tables
            db.execute('DELETE FROM tasks')
            db.execute('DELETE FROM users')
            db.commit()

            # Create test user
            self.test_user = User.create_user('testuser', 'test@example.com', 'password123')

    def test_create_task_success(self):
        """Test successful task creation"""
        with app.app_context():
            due_date = datetime.utcnow() + timedelta(days=1)
            task = Task.create_task(
                user_id=self.test_user.id,
                title='Test Task',
                description='Test description',
                priority='high',
                due_date=due_date
            )

            assert task is not None
            assert task.title == 'Test Task'
            assert task.description == 'Test description'
            assert task.priority == 'high'
            assert task.status == 'pending'
            assert task.user_id == self.test_user.id

    def test_get_task_by_id(self):
        """Test getting task by ID"""
        with app.app_context():
            task = Task.create_task(
                user_id=self.test_user.id,
                title='Test Task',
                description='Test description'
            )

            retrieved = Task.get_task_by_id(task.id, user_id=self.test_user.id)
            assert retrieved is not None
            assert retrieved.id == task.id
            assert retrieved.title == 'Test Task'

    def test_get_task_by_id_wrong_user(self):
        """Test getting task by ID with wrong user"""
        with app.app_context():
            # Create another user
            other_user = User.create_user('otheruser', 'other@example.com', 'password123')

            task = Task.create_task(
                user_id=self.test_user.id,
                title='Test Task'
            )

            # Try to get task with wrong user ID
            retrieved = Task.get_task_by_id(task.id, user_id=other_user.id)
            assert retrieved is None

    def test_get_tasks_by_user(self):
        """Test getting tasks by user"""
        with app.app_context():
            # Create multiple tasks
            Task.create_task(user_id=self.test_user.id, title='Task 1', priority='high')
            Task.create_task(user_id=self.test_user.id, title='Task 2', priority='medium')
            Task.create_task(user_id=self.test_user.id, title='Task 3', priority='low')

            tasks = Task.get_tasks_by_user(self.test_user.id)
            assert len(tasks) == 3

            # Test filtering by priority
            high_tasks = Task.get_tasks_by_user(self.test_user.id, priority='high')
            assert len(high_tasks) == 1
            assert high_tasks[0].title == 'Task 1'

    def test_update_task(self):
        """Test updating task"""
        with app.app_context():
            task = Task.create_task(
                user_id=self.test_user.id,
                title='Original Title',
                description='Original description'
            )

            success = task.update_task(
                title='Updated Title',
                description='Updated description',
                status='in_progress',
                priority='urgent'
            )

            assert success == True

            # Verify changes
            updated = Task.get_task_by_id(task.id, user_id=self.test_user.id)
            assert updated.title == 'Updated Title'
            assert updated.description == 'Updated description'
            assert updated.status == 'in_progress'
            assert updated.priority == 'urgent'

    def test_delete_task(self):
        """Test deleting task"""
        with app.app_context():
            task = Task.create_task(user_id=self.test_user.id, title='Test Task')

            # Delete task
            success = Task.delete_task_by_id(task.id, user_id=self.test_user.id)
            assert success == True

            # Verify deletion
            retrieved = Task.get_task_by_id(task.id, user_id=self.test_user.id)
            assert retrieved is None

    def test_task_stats(self):
        """Test task statistics"""
        with app.app_context():
            # Create tasks with different statuses
            task1 = Task.create_task(user_id=self.test_user.id, title='Task 1')
            task1.update_task(status='completed')
            task2 = Task.create_task(user_id=self.test_user.id, title='Task 2')
            task2.update_task(status='in_progress')
            Task.create_task(user_id=self.test_user.id, title='Task 3')  # status defaults to pending
            Task.create_task(user_id=self.test_user.id, title='Task 4', priority='urgent')

            stats = Task.get_task_stats(user_id=self.test_user.id)
            assert stats['total_tasks'] == 4
            assert stats['completed_tasks'] == 1
            assert stats['in_progress_tasks'] == 1
            assert stats['pending_tasks'] == 2
            assert stats['urgent_tasks'] == 1

    def test_search_tasks(self):
        """Test task search"""
        with app.app_context():
            Task.create_task(user_id=self.test_user.id, title='Buy groceries', description='Milk, bread, eggs')
            Task.create_task(user_id=self.test_user.id, title='Write report', description='Quarterly report')
            Task.create_task(user_id=self.test_user.id, title='Call client', description='Discuss project')

            # Search by title
            results = Task.search_tasks(self.test_user.id, 'report')
            assert len(results) == 1
            assert results[0].title == 'Write report'

            # Search by description
            results = Task.search_tasks(self.test_user.id, 'project')
            assert len(results) == 1
            assert results[0].title == 'Call client'


class TestTaskEndpoints:
    """Test task API endpoints"""

    def setup_method(self):
        """Setup test client and test user"""
        self.client = app.test_client()
        with app.app_context():
            db = get_db()
            db.execute('DELETE FROM tasks')
            db.execute('DELETE FROM users')
            db.commit()

            # Create test user
            self.test_user = User.create_user('testuser', 'test@example.com', 'password123')

            # Login to get session
            with self.client:
                self.client.post('/api/auth/login', json={
                    'username': 'testuser',
                    'password': 'password123'
                })

    def test_get_tasks(self):
        """Test getting tasks"""
        with app.app_context():
            # Create test tasks
            Task.create_task(user_id=self.test_user.id, title='Task 1')
            Task.create_task(user_id=self.test_user.id, title='Task 2')

        response = self.client.get('/api/tasks/')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'tasks' in data
        assert len(data['tasks']) == 2

    def test_create_task(self):
        """Test creating a task"""
        task_data = {
            'title': 'New Task',
            'description': 'Task description',
            'priority': 'high',
            'due_date': (datetime.utcnow() + timedelta(days=1)).isoformat()
        }

        response = self.client.post('/api/tasks/', json=task_data)
        assert response.status_code == 201
        data = json.loads(response.data)
        assert 'task' in data
        assert data['task']['title'] == 'New Task'
        assert data['task']['priority'] == 'high'

    def test_create_task_missing_title(self):
        """Test creating task without title"""
        response = self.client.post('/api/tasks/', json={
            'description': 'Task without title'
        })
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data

    def test_get_task_by_id(self):
        """Test getting specific task"""
        with app.app_context():
            task = Task.create_task(user_id=self.test_user.id, title='Specific Task')

        response = self.client.get(f'/api/tasks/{task.id}')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['title'] == 'Specific Task'

    def test_get_nonexistent_task(self):
        """Test getting nonexistent task"""
        response = self.client.get('/api/tasks/99999')
        assert response.status_code == 404
        data = json.loads(response.data)
        assert 'error' in data

    def test_update_task(self):
        """Test updating a task"""
        with app.app_context():
            task = Task.create_task(user_id=self.test_user.id, title='Original Task')

        update_data = {
            'title': 'Updated Task',
            'status': 'completed',
            'priority': 'urgent'
        }

        response = self.client.put(f'/api/tasks/{task.id}', json=update_data)
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['task']['title'] == 'Updated Task'
        assert data['task']['status'] == 'completed'
        assert data['task']['priority'] == 'urgent'

    def test_delete_task(self):
        """Test deleting a task"""
        with app.app_context():
            task = Task.create_task(user_id=self.test_user.id, title='Task to Delete')

        response = self.client.delete(f'/api/tasks/{task.id}')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'message' in data

        # Verify deletion
        response = self.client.get(f'/api/tasks/{task.id}')
        assert response.status_code == 404

    def test_update_task_status(self):
        """Test updating task status"""
        with app.app_context():
            task = Task.create_task(user_id=self.test_user.id, title='Status Test Task')

        response = self.client.patch(f'/api/tasks/{task.id}/status', json={
            'status': 'completed'
        })
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['task']['status'] == 'completed'

    def test_get_task_stats(self):
        """Test getting task statistics"""
        with app.app_context():
            task1 = Task.create_task(user_id=self.test_user.id, title='Task 1')
            task1.update_task(status='completed')
            task2 = Task.create_task(user_id=self.test_user.id, title='Task 2')
            task2.update_task(status='in_progress')

        response = self.client.get('/api/tasks/stats')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['total_tasks'] == 2
        assert data['completed_tasks'] == 1
        assert data['in_progress_tasks'] == 1

    def test_search_tasks(self):
        """Test searching tasks"""
        with app.app_context():
            Task.create_task(user_id=self.test_user.id, title='Buy groceries')
            Task.create_task(user_id=self.test_user.id, title='Write report')

        response = self.client.get('/api/tasks/search?q=report')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data['tasks']) == 1
        assert data['tasks'][0]['title'] == 'Write report'

    def test_search_tasks_no_query(self):
        """Test searching tasks without query"""
        response = self.client.get('/api/tasks/search')
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data