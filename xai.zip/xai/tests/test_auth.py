"""
Unit tests for authentication functionality
"""

import pytest
import json
from unittest.mock import patch, MagicMock
from server import app, create_user, authenticate_user, get_db


class TestAuthentication:
    """Test authentication functions"""

    def setup_method(self):
        """Setup test database"""
        with app.app_context():
            db = get_db()
            # Clear tables
            db.execute('DELETE FROM users')
            db.execute('DELETE FROM api_usage')
            db.commit()

    def test_create_user_success(self):
        """Test successful user creation"""
        with app.app_context():
            result = create_user('testuser', 'test@example.com', 'password123')
            assert result == True

            # Verify user was created
            db = get_db()
            user = db.execute('SELECT * FROM users WHERE username = ?', ('testuser',)).fetchone()
            assert user is not None
            assert user['email'] == 'test@example.com'
            assert user['role'] == 'user'

    def test_create_user_duplicate_username(self):
        """Test creating user with duplicate username"""
        with app.app_context():
            create_user('testuser', 'test1@example.com', 'password123')
            result = create_user('testuser', 'test2@example.com', 'password456')
            assert result == False

    def test_create_user_duplicate_email(self):
        """Test creating user with duplicate email"""
        with app.app_context():
            create_user('user1', 'test@example.com', 'password123')
            result = create_user('user2', 'test@example.com', 'password456')
            assert result == False

    def test_authenticate_user_success(self):
        """Test successful user authentication"""
        with app.app_context():
            create_user('testuser', 'test@example.com', 'password123')
            user = authenticate_user('testuser', 'password123')
            assert user is not None
            assert user['username'] == 'testuser'
            assert user['email'] == 'test@example.com'

    def test_authenticate_user_wrong_password(self):
        """Test authentication with wrong password"""
        with app.app_context():
            create_user('testuser', 'test@example.com', 'password123')
            user = authenticate_user('testuser', 'wrongpassword')
            assert user is None

    def test_authenticate_user_nonexistent(self):
        """Test authentication of nonexistent user"""
        with app.app_context():
            user = authenticate_user('nonexistent', 'password123')
            assert user is None


class TestAuthEndpoints:
    """Test authentication API endpoints"""

    def setup_method(self):
        """Setup test client"""
        self.client = app.test_client()
        with app.app_context():
            db = get_db()
            db.execute('DELETE FROM users')
            db.commit()

    def test_register_success(self):
        """Test successful user registration"""
        response = self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        assert response.status_code == 201
        data = json.loads(response.data)
        assert 'message' in data

    def test_register_missing_fields(self):
        """Test registration with missing fields"""
        response = self.client.post('/api/auth/register', json={
            'username': 'testuser'
        })
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data

    def test_register_short_password(self):
        """Test registration with short password"""
        response = self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': '123'
        })
        assert response.status_code == 400
        data = json.loads(response.data)
        assert 'error' in data

    def test_login_success(self):
        """Test successful login"""
        # Register user first
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })

        # Login
        response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'token' in data
        assert 'user' in data

    def test_login_wrong_credentials(self):
        """Test login with wrong credentials"""
        response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'wrongpassword'
        })
        assert response.status_code == 401
        data = json.loads(response.data)
        assert 'error' in data

    @patch('server.session')
    def test_logout(self, mock_session):
        """Test logout"""
        response = self.client.post('/api/auth/logout')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'message' in data
        mock_session.clear.assert_called_once()

    def test_health_endpoint(self):
        """Test health check endpoint"""
        response = self.client.get('/health')
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'status' in data
        assert data['status'] == 'online'