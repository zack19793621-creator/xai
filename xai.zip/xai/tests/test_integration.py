"""
Integration tests for AI Orchestrator
"""

import pytest
import json
from unittest.mock import patch, MagicMock
from server import app


class TestAIIntegration:
    """Test AI model integrations"""

    def setup_method(self):
        """Setup test client"""
        self.client = app.test_client()

    @patch('requests.post')
    def test_groq_chat_success(self, mock_post):
        """Test successful Groq chat"""
        # Mock successful response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'choices': [{'message': {'content': 'Test response'}}]
        }
        mock_post.return_value = mock_response

        # Login first to get authentication
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        login_response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        token = json.loads(login_response.data)['token']

        # Test Groq endpoint
        response = self.client.post('/api/groq/chat',
            json={'messages': [{'role': 'user', 'content': 'Hello'}]},
            headers={'Authorization': f'Bearer {token}'}
        )
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'choices' in data

    @patch('requests.post')
    def test_groq_chat_api_error(self, mock_post):
        """Test Groq chat with API error"""
        # Mock error response
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.text = 'Internal server error'
        mock_post.return_value = mock_response

        # Login first
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        login_response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        token = json.loads(login_response.data)['token']

        # Test Groq endpoint
        response = self.client.post('/api/groq/chat',
            json={'messages': [{'role': 'user', 'content': 'Hello'}]},
            headers={'Authorization': f'Bearer {token}'}
        )
        assert response.status_code == 500
        data = json.loads(response.data)
        assert 'error' in data

    @patch('requests.post')
    def test_multi_ai_consensus(self, mock_post):
        """Test multi-AI consensus"""
        # Mock responses for different models
        def mock_response_side_effect(*args, **kwargs):
            url = args[0]
            mock_response = MagicMock()
            mock_response.status_code = 200

            if 'groq' in url:
                mock_response.json.return_value = {
                    'choices': [{'message': {'content': 'Groq response'}}]
                }
            elif 'mistral' in url:
                mock_response.json.return_value = {
                    'choices': [{'message': {'content': 'Mistral response'}}]
                }
            elif 'cohere' in url:
                mock_response.json.return_value = {'text': 'Cohere response'}
            elif 'generativelanguage' in url:
                mock_response.json.return_value = {
                    'candidates': [{'content': {'parts': [{'text': 'Gemini response'}]}}]
                }
            elif 'huggingface' in url:
                mock_response.json.return_value = [{'generated_text': 'HuggingFace response'}]

            return mock_response

        mock_post.side_effect = mock_response_side_effect

        # Login first
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        login_response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        token = json.loads(login_response.data)['token']

        # Test multi-AI endpoint
        response = self.client.post('/api/multi-ai',
            json={'prompt': 'Test prompt'},
            headers={'Authorization': f'Bearer {token}'}
        )
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'results' in data
        assert 'consensus' in data
        assert len(data['results']) > 0


class TestAndroidOrchestrator:
    """Test Android orchestrator functionality"""

    def setup_method(self):
        """Setup test client"""
        self.client = app.test_client()

    @patch('server.AndroidOrchestrator')
    def test_android_autonomous(self, mock_orchestrator_class):
        """Test Android autonomous mode"""
        # Mock orchestrator instance
        mock_orchestrator = MagicMock()
        mock_orchestrator.process_request.return_value = {
            'success': True,
            'message': 'Task completed'
        }
        mock_orchestrator_class.return_value = mock_orchestrator

        # Login first
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        login_response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        token = json.loads(login_response.data)['token']

        # Test autonomous endpoint
        response = self.client.post('/api/android/autonomous',
            json={'request': 'Create a test activity'},
            headers={'Authorization': f'Bearer {token}'}
        )
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'success' in data

    @patch('server.AndroidOrchestrator')
    def test_android_build(self, mock_orchestrator_class):
        """Test Android build functionality"""
        # Mock orchestrator instance
        mock_orchestrator = MagicMock()
        mock_orchestrator.run_gradle_build.return_value = MagicMock(
            success=True,
            output='Build successful',
            errors=[],
            apk_path='/path/to/app.apk',
            duration=45.2
        )
        mock_orchestrator_class.return_value = mock_orchestrator

        # Login first
        self.client.post('/api/auth/register', json={
            'username': 'testuser',
            'email': 'test@example.com',
            'password': 'password123'
        })
        login_response = self.client.post('/api/auth/login', json={
            'username': 'testuser',
            'password': 'password123'
        })
        token = json.loads(login_response.data)['token']

        # Test build endpoint
        response = self.client.post('/api/android/build',
            json={'task': 'assembleDebug'},
            headers={'Authorization': f'Bearer {token}'}
        )
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] == True
        assert 'apk_path' in data


class TestRateLimiting:
    """Test rate limiting functionality"""

    def setup_method(self):
        """Setup test client"""
        self.client = app.test_client()

    def test_rate_limit_exceeded(self):
        """Test rate limiting on auth endpoints"""
        # Make multiple registration attempts
        for i in range(10):
            response = self.client.post('/api/auth/register', json={
                'username': f'user{i}',
                'email': f'user{i}@example.com',
                'password': 'password123'
            })

        # Should eventually be rate limited
        response = self.client.post('/api/auth/register', json={
            'username': 'finaluser',
            'email': 'final@example.com',
            'password': 'password123'
        })

        # Rate limiting might return 429 or still allow depending on configuration
        assert response.status_code in [201, 429]