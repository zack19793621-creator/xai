"""
AI File System Agent - Core file operations for automatic file creation and management
"""

import os
import json
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import difflib
import hashlib


class FileOperationResult:
    """Result of a file operation"""

    def __init__(self, success: bool, message: str, error: Optional[str] = None, data: Optional[Dict] = None):
        self.success = success
        self.message = message
        self.error = error
        self.data = data or {}


class ChangeHistory:
    """Track file changes for undo functionality"""

    def __init__(self, action: str, file_path: str, old_content: Optional[str] = None, new_content: Optional[str] = None):
        self.action = action
        self.file_path = file_path
        self.old_content = old_content
        self.new_content = new_content
        self.timestamp = datetime.now()


class AIFileSystemAgent:
    """
    Core file system operations for AI agents
    Provides safe, tracked file operations with user confirmation when needed
    """

    def __init__(self, project_root: str, safe_mode: bool = True, backup_enabled: bool = True):
        """
        Initialize the file system agent

        Args:
            project_root: Root directory for all operations
            safe_mode: Whether to ask for confirmation before changes
            backup_enabled: Whether to create backups before destructive operations
        """
        self.project_root = Path(project_root).resolve()
        self.safe_mode = safe_mode
        self.backup_enabled = backup_enabled
        self.changes_history: List[ChangeHistory] = []
        self.backup_dir = self.project_root / ".ai_backups"

        # Create backup directory if needed
        if backup_enabled:
            self.backup_dir.mkdir(exist_ok=True)

        # Validate project root exists
        if not self.project_root.exists():
            raise ValueError(f"Project root does not exist: {self.project_root}")

    def _normalize_path(self, file_path: str) -> Path:
        """Normalize and validate file path within project root"""
        path = Path(file_path)

        # Convert to absolute path
        if not path.is_absolute():
            path = self.project_root / path

        # Resolve any symlinks and normalize
        path = path.resolve()

        # Security check: ensure path is within project root
        try:
            path.relative_to(self.project_root)
        except ValueError:
            raise ValueError(f"Path is outside project root: {path}")

        return path

    def _create_backup(self, file_path: Path) -> Optional[Path]:
        """Create a backup of a file before modification"""
        if not self.backup_enabled or not file_path.exists():
            return None

        # Create backup filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{file_path.name}.{timestamp}.backup"
        backup_path = self.backup_dir / backup_name

        try:
            shutil.copy2(file_path, backup_path)
            return backup_path
        except Exception as e:
            print(f"Warning: Failed to create backup: {e}")
            return None

    def _should_confirm(self, action: str, file_path: str, content: Optional[str] = None) -> bool:
        """Determine if user confirmation is needed"""
        if not self.safe_mode:
            return False

        # Always confirm for destructive operations
        if action in ['delete_file', 'edit_file']:
            return True

        # Confirm for new files in sensitive directories
        sensitive_dirs = ['config', 'secrets', 'private', '.env']
        if any(sensitive in file_path.lower() for sensitive in sensitive_dirs):
            return True

        return False

    def _get_diff_preview(self, old_content: str, new_content: str, file_path: str) -> str:
        """Generate a diff preview for file changes"""
        old_lines = old_content.splitlines(keepends=True) if old_content else []
        new_lines = new_content.splitlines(keepends=True) if new_content else []

        diff = list(difflib.unified_diff(
            old_lines, new_lines,
            fromfile=f"a/{file_path}",
            tofile=f"b/{file_path}",
            lineterm=""
        ))

        return "".join(diff) if diff else "No changes detected"

    def create_file(self, file_path: str, content: str, encoding: str = 'utf-8') -> FileOperationResult:
        """
        Create a new file with the given content

        Args:
            file_path: Path to the file (relative to project root)
            content: File content
            encoding: File encoding

        Returns:
            FileOperationResult with success status and message
        """
        try:
            path = self._normalize_path(file_path)

            # Check if file already exists
            if path.exists():
                return FileOperationResult(
                    success=False,
                    message=f"File already exists: {file_path}",
                    error="FILE_EXISTS"
                )

            # Check if user confirmation is needed
            if self._should_confirm('create_file', file_path, content):
                return FileOperationResult(
                    success=False,
                    message=f"User confirmation required for creating: {file_path}",
                    error="CONFIRMATION_REQUIRED",
                    data={
                        'action': 'create_file',
                        'file_path': file_path,
                        'content_preview': content[:200] + "..." if len(content) > 200 else content,
                        'requires_confirmation': True
                    }
                )

            # Create parent directories
            path.parent.mkdir(parents=True, exist_ok=True)

            # Write file
            with open(path, 'w', encoding=encoding) as f:
                f.write(content)

            # Track change
            self.changes_history.append(ChangeHistory(
                action='create',
                file_path=str(path),
                new_content=content
            ))

            return FileOperationResult(
                success=True,
                message=f"File created successfully: {file_path}",
                data={
                    'file_path': file_path,
                    'size': len(content),
                    'encoding': encoding
                }
            )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to create file: {file_path}",
                error=str(e)
            )

    def edit_file(self, file_path: str, new_content: str, encoding: str = 'utf-8') -> FileOperationResult:
        """
        Edit an existing file

        Args:
            file_path: Path to the file (relative to project root)
            new_content: New file content
            encoding: File encoding

        Returns:
            FileOperationResult with success status and message
        """
        try:
            path = self._normalize_path(file_path)

            # Check if file exists
            if not path.exists():
                return FileOperationResult(
                    success=False,
                    message=f"File does not exist: {file_path}",
                    error="FILE_NOT_FOUND"
                )

            # Read current content
            with open(path, 'r', encoding=encoding) as f:
                old_content = f.read()

            # Check if content is actually different
            if old_content == new_content:
                return FileOperationResult(
                    success=True,
                    message=f"No changes needed for: {file_path}",
                    data={'unchanged': True}
                )

            # Check if user confirmation is needed
            if self._should_confirm('edit_file', file_path, new_content):
                diff_preview = self._get_diff_preview(old_content, new_content, file_path)
                return FileOperationResult(
                    success=False,
                    message=f"User confirmation required for editing: {file_path}",
                    error="CONFIRMATION_REQUIRED",
                    data={
                        'action': 'edit_file',
                        'file_path': file_path,
                        'diff_preview': diff_preview,
                        'old_content_length': len(old_content),
                        'new_content_length': len(new_content),
                        'requires_confirmation': True
                    }
                )

            # Create backup
            backup_path = self._create_backup(path)

            # Write new content
            with open(path, 'w', encoding=encoding) as f:
                f.write(new_content)

            # Track change
            self.changes_history.append(ChangeHistory(
                action='edit',
                file_path=str(path),
                old_content=old_content,
                new_content=new_content
            ))

            return FileOperationResult(
                success=True,
                message=f"File edited successfully: {file_path}",
                data={
                    'file_path': file_path,
                    'old_size': len(old_content),
                    'new_size': len(new_content),
                    'backup_path': str(backup_path) if backup_path else None
                }
            )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to edit file: {file_path}",
                error=str(e)
            )

    def read_file(self, file_path: str, encoding: str = 'utf-8') -> FileOperationResult:
        """
        Read file content

        Args:
            file_path: Path to the file (relative to project root)
            encoding: File encoding

        Returns:
            FileOperationResult with file content
        """
        try:
            path = self._normalize_path(file_path)

            if not path.exists():
                return FileOperationResult(
                    success=False,
                    message=f"File does not exist: {file_path}",
                    error="FILE_NOT_FOUND"
                )

            with open(path, 'r', encoding=encoding) as f:
                content = f.read()

            return FileOperationResult(
                success=True,
                message=f"File read successfully: {file_path}",
                data={
                    'content': content,
                    'size': len(content),
                    'encoding': encoding,
                    'file_path': file_path
                }
            )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to read file: {file_path}",
                error=str(e)
            )

    def delete_file(self, file_path: str) -> FileOperationResult:
        """
        Delete a file

        Args:
            file_path: Path to the file (relative to project root)

        Returns:
            FileOperationResult with success status
        """
        try:
            path = self._normalize_path(file_path)

            if not path.exists():
                return FileOperationResult(
                    success=False,
                    message=f"File does not exist: {file_path}",
                    error="FILE_NOT_FOUND"
                )

            # Check if user confirmation is needed
            if self._should_confirm('delete_file', file_path):
                return FileOperationResult(
                    success=False,
                    message=f"User confirmation required for deleting: {file_path}",
                    error="CONFIRMATION_REQUIRED",
                    data={
                        'action': 'delete_file',
                        'file_path': file_path,
                        'requires_confirmation': True
                    }
                )

            # Read content before deletion for backup
            content = None
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
            except:
                pass  # Ignore read errors for deletion

            # Create backup if content was readable
            backup_path = None
            if content is not None:
                backup_path = self._create_backup(path)

            # Delete file
            path.unlink()

            # Track change
            self.changes_history.append(ChangeHistory(
                action='delete',
                file_path=str(path),
                old_content=content
            ))

            return FileOperationResult(
                success=True,
                message=f"File deleted successfully: {file_path}",
                data={
                    'file_path': file_path,
                    'backup_path': str(backup_path) if backup_path else None
                }
            )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to delete file: {file_path}",
                error=str(e)
            )

    def list_files(self, directory: str = ".", recursive: bool = False) -> FileOperationResult:
        """
        List files in a directory

        Args:
            directory: Directory path (relative to project root)
            recursive: Whether to list recursively

        Returns:
            FileOperationResult with file list
        """
        try:
            path = self._normalize_path(directory)

            if not path.exists():
                return FileOperationResult(
                    success=False,
                    message=f"Directory does not exist: {directory}",
                    error="DIRECTORY_NOT_FOUND"
                )

            if not path.is_dir():
                return FileOperationResult(
                    success=False,
                    message=f"Path is not a directory: {directory}",
                    error="NOT_A_DIRECTORY"
                )

            files = []
            if recursive:
                for root, dirs, filenames in os.walk(path):
                    for filename in filenames:
                        full_path = Path(root) / filename
                        rel_path = full_path.relative_to(self.project_root)
                        files.append({
                            'path': str(rel_path),
                            'size': full_path.stat().st_size,
                            'modified': datetime.fromtimestamp(full_path.stat().st_mtime).isoformat()
                        })
            else:
                for item in path.iterdir():
                    if item.is_file():
                        rel_path = item.relative_to(self.project_root)
                        files.append({
                            'path': str(rel_path),
                            'size': item.stat().st_size,
                            'modified': datetime.fromtimestamp(item.stat().st_mtime).isoformat()
                        })

            return FileOperationResult(
                success=True,
                message=f"Listed {len(files)} files in {directory}",
                data={
                    'files': files,
                    'count': len(files),
                    'directory': directory
                }
            )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to list files in: {directory}",
                error=str(e)
            )

    def get_tools_definition(self) -> List[Dict[str, Any]]:
        """
        Get tool definitions for AI function calling

        Returns:
            List of tool definitions compatible with OpenAI/Claude function calling
        """
        return [
            {
                "type": "function",
                "function": {
                    "name": "create_file",
                    "description": "Create a new file with the specified content",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to the file (relative to project root)"
                            },
                            "content": {
                                "type": "string",
                                "description": "Content to write to the file"
                            },
                            "encoding": {
                                "type": "string",
                                "description": "File encoding (default: utf-8)",
                                "default": "utf-8"
                            }
                        },
                        "required": ["file_path", "content"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "edit_file",
                    "description": "Edit an existing file with new content",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to the file (relative to project root)"
                            },
                            "content": {
                                "type": "string",
                                "description": "New content for the file"
                            },
                            "encoding": {
                                "type": "string",
                                "description": "File encoding (default: utf-8)",
                                "default": "utf-8"
                            }
                        },
                        "required": ["file_path", "content"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "read_file",
                    "description": "Read the content of a file",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to the file (relative to project root)"
                            },
                            "encoding": {
                                "type": "string",
                                "description": "File encoding (default: utf-8)",
                                "default": "utf-8"
                            }
                        },
                        "required": ["file_path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "delete_file",
                    "description": "Delete a file",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "file_path": {
                                "type": "string",
                                "description": "Path to the file (relative to project root)"
                            }
                        },
                        "required": ["file_path"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "list_files",
                    "description": "List files in a directory",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "directory": {
                                "type": "string",
                                "description": "Directory path (relative to project root, default: \".\")",
                                "default": "."
                            },
                            "recursive": {
                                "type": "boolean",
                                "description": "Whether to list files recursively",
                                "default": False
                            }
                        }
                    }
                }
            }
        ]

    def execute_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool by name with given parameters

        Args:
            tool_name: Name of the tool to execute
            params: Tool parameters

        Returns:
            Dictionary with execution result
        """
        try:
            if tool_name == "create_file":
                result = self.create_file(
                    params["file_path"],
                    params["content"],
                    params.get("encoding", "utf-8")
                )
            elif tool_name == "edit_file":
                result = self.edit_file(
                    params["file_path"],
                    params["content"],
                    params.get("encoding", "utf-8")
                )
            elif tool_name == "read_file":
                result = self.read_file(
                    params["file_path"],
                    params.get("encoding", "utf-8")
                )
            elif tool_name == "delete_file":
                result = self.delete_file(params["file_path"])
            elif tool_name == "list_files":
                result = self.list_files(
                    params.get("directory", "."),
                    params.get("recursive", False)
                )
            else:
                return {
                    "success": False,
                    "error": f"Unknown tool: {tool_name}",
                    "message": f"Tool '{tool_name}' is not supported"
                }

            # Convert result to dictionary
            return {
                "success": result.success,
                "message": result.message,
                "error": result.error,
                "data": result.data
            }

        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "message": f"Tool execution failed: {tool_name}"
            }

    def get_change_history(self) -> List[Dict[str, Any]]:
        """
        Get the history of all changes made

        Returns:
            List of change records
        """
        return [
            {
                "action": change.action,
                "file_path": change.file_path,
                "timestamp": change.timestamp.isoformat(),
                "has_old_content": change.old_content is not None,
                "has_new_content": change.new_content is not None
            }
            for change in self.changes_history
        ]

    def undo_last_change(self) -> FileOperationResult:
        """
        Undo the last change made

        Returns:
            FileOperationResult with undo status
        """
        if not self.changes_history:
            return FileOperationResult(
                success=False,
                message="No changes to undo",
                error="NO_CHANGES"
            )

        last_change = self.changes_history.pop()

        try:
            if last_change.action == "create":
                # Undo create by deleting the file
                path = Path(last_change.file_path)
                if path.exists():
                    path.unlink()
                return FileOperationResult(
                    success=True,
                    message=f"Undid file creation: {last_change.file_path}"
                )

            elif last_change.action == "edit":
                # Undo edit by restoring old content
                path = Path(last_change.file_path)
                if last_change.old_content is not None:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(last_change.old_content)
                return FileOperationResult(
                    success=True,
                    message=f"Undid file edit: {last_change.file_path}"
                )

            elif last_change.action == "delete":
                # Undo delete by recreating the file
                path = Path(last_change.file_path)
                path.parent.mkdir(parents=True, exist_ok=True)
                if last_change.old_content is not None:
                    with open(path, 'w', encoding='utf-8') as f:
                        f.write(last_change.old_content)
                return FileOperationResult(
                    success=True,
                    message=f"Undid file deletion: {last_change.file_path}"
                )

            else:
                return FileOperationResult(
                    success=False,
                    message=f"Cannot undo action: {last_change.action}",
                    error="UNSUPPORTED_UNDO"
                )

        except Exception as e:
            return FileOperationResult(
                success=False,
                message=f"Failed to undo change: {str(e)}",
                error=str(e)
            )